package odoo.client.helper;


import odoo.client.helper.data.OdooError;
import odoo.client.helper.data.OdooResult;

public class OdooResponse {
    public int id;
    public float jsonrpc;
    public OdooResult result;
    public OdooError error;
}
