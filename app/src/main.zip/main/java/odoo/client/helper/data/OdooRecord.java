package odoo.client.helper.data;


public class OdooRecord extends OdooResult {

}
