package odoo.client;

public enum AuthError {
    DatabaseNotFound,
    AuthenticationFailed
}
