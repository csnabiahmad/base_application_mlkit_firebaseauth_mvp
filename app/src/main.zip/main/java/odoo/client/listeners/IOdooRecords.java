package odoo.client.listeners;


import odoo.client.builder.data.OdooRecords;

public interface IOdooRecords {

    void onRecords(OdooRecords records);
}
