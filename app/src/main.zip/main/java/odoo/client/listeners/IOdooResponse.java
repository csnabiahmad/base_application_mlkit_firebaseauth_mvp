package odoo.client.listeners;


import odoo.client.helper.OdooErrorException;
import odoo.client.helper.data.OdooResult;

public abstract class IOdooResponse {

    public String requestingURL = null;
    public int uuid = 0;

    public abstract void onResult(OdooResult result);

    public boolean onError(OdooErrorException error) {
        return false;
    }
}
