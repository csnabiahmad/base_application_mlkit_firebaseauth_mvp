package odoo.client.listeners;


import odoo.client.OdooVersion;

public interface OdooConnectListener {
    void onConnected(OdooVersion version);
}
