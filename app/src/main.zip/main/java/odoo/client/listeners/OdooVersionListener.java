package odoo.client.listeners;


import odoo.client.OdooVersion;

public interface OdooVersionListener {
    void onVersionLoad(OdooVersion version);
}
