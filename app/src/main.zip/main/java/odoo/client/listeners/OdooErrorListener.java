package odoo.client.listeners;


import odoo.client.helper.OdooErrorException;

public interface OdooErrorListener {
    void onError(OdooErrorException error);
}
