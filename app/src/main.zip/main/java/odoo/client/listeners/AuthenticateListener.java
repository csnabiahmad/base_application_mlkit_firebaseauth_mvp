package odoo.client.listeners;


import odoo.OdooUser;
import odoo.client.AuthError;

public interface AuthenticateListener {
    void onLoginSuccess(OdooUser user);

    void onLoginFail(AuthError error);
}
