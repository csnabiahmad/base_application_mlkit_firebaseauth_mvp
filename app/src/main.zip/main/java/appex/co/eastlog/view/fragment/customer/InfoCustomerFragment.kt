package appex.co.eastlog.view.fragment.customer

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import appex.co.eastlog.R
import appex.co.eastlog.model.Customer
import appex.co.eastlog.utils.Utils
import appex.co.eastlog.viewmodel.CustomerViewModel
import kotlinx.android.synthetic.main.fragment_info_customer.*

class InfoCustomerFragment : Fragment(), LifecycleOwner {

    private var mCustomerViewModel: CustomerViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_info_customer, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        Utils.hideSoftKeyboard(activity!!)
        mCustomerViewModel = ViewModelProviders.of(activity!!)[CustomerViewModel::class.java]
        mCustomerViewModel?.getCustomer()?.observe(this, Observer<Customer> {
            mTextInputEditTextName.setText(Utils.getString(it?.displayName))
            mTextInputEditTextMobile.setText(Utils.getString(it?.mobile))
            mTextInputEditTextPhone.setText(Utils.getString(it?.phone))
            mTextInputEditTextEmail.setText(Utils.getString(it?.email))
            mTextInputEditTextStreet.setText(Utils.getString(it?.street))
            mTextInputEditTextStreet2.setText(Utils.getString(it?.street2))
            mTextInputEditTextCity.setText(Utils.getString(it?.city))
            mTextInputEditTextZip.setText(Utils.getString(it?.zip))
            mTextInputEditTextWebsite.setText(Utils.getString(it?.website))
            mTextInputEditTextCountry.setText(Utils.getString(it?.countryId.toString()))
        })
        if (mCustomerViewModel?.getCustomer()?.value?.id == null) {
            mTextInputEditTextName.visibility = View.VISIBLE
            updateViewInput(true)
        } else {
            mTextInputEditTextName.visibility = View.GONE
            updateViewInput(false)
        }
    }


    override fun onDetach() {
        super.onDetach()
    }

    fun updateViewInput(edit: Boolean) {
        mTextInputEditTextName.isEnabled = edit
        mTextInputEditTextStreet.isEnabled = edit
        mTextInputEditTextStreet2.isEnabled = edit
        mTextInputEditTextCity.isEnabled = edit
        mTextInputEditTextZip.isEnabled = edit
        mTextInputEditTextCountry.isEnabled = edit
        mTextInputEditTextPhone.isEnabled = edit
        mTextInputEditTextMobile.isEnabled = edit
        mTextInputEditTextEmail.isEnabled = edit
        mTextInputEditTextWebsite.isEnabled = edit
    }

    fun getCustomer(): Customer {
        val customer = Customer()
        customer.displayName = mTextInputEditTextName.text.toString()
        customer.street = mTextInputEditTextStreet.text.toString()
        customer.street2 = mTextInputEditTextStreet2.text.toString()
        customer.city = mTextInputEditTextCity.text.toString()
        customer.zip = mTextInputEditTextZip.text.toString()
        customer.countryId = mTextInputEditTextCountry.text.toString()
        customer.phone = mTextInputEditTextPhone.text.toString()
        customer.mobile = mTextInputEditTextMobile.text.toString()
        customer.email = mTextInputEditTextEmail.text.toString()
        customer.website = mTextInputEditTextWebsite.text.toString()
        return customer
    }

}
