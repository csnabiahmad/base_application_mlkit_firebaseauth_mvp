package appex.co.eastlog.view.fragment

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.InvoicesAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.InvoicesModel
import appex.co.eastlog.utils.Utils
import appex.co.eastlog.view.activity.CreateInvoiceActivity
import appex.co.eastlog.view.activity.InvoicesDetailActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_invoices.*
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.listeners.IOdooResponse


class InvoicesFragment : Fragment(), AbstractAdapter.ListItemInteractionListener {

    private var mProgressDlg: ProgressDlg? = null
    private var mInvoicesAdapter: InvoicesAdapter? = null
    private var mListData: ArrayList<InvoicesModel>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_invoices, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mListData = ArrayList()
        mInvoicesAdapter = InvoicesAdapter(activity!!, mListData)
        mInvoicesAdapter?.setItemInteractionListener(this)
        mProgressDlg = ProgressDlg(activity)

        val mLayoutManager = LinearLayoutManager(activity)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewInvoices.layoutManager = mLayoutManager
        mRecyclerViewInvoices.setHasFixedSize(true)
        mRecyclerViewInvoices.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewInvoices.adapter = mInvoicesAdapter
        mRecyclerViewInvoices.addOnScrollListener(object : RecyclerView.OnScrollListener(){
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (dy > 0) mFloatingActionButtonAddInvoice.hide()
                else mFloatingActionButtonAddInvoice.show()
                super.onScrolled(recyclerView, dx, dy)
            }
        })

        mSwipeRefreshLayout.setOnRefreshListener {
            getData()
        }

        mFloatingActionButtonAddInvoice.setOnClickListener {
            val intent = Intent(activity, CreateInvoiceActivity::class.java)
            activity!!.startActivityForResult(intent, INVOICE_CODE_UPDATE)
        }

        //search invoice
        mSearchViewInvoice.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextChange(newText: String?): Boolean {
                activity!!.runOnUiThread {
                    mInvoicesAdapter?.filter?.filter(newText)
                }
                return false
            }

            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

        })


    }

    override fun onResume() {
        super.onResume()
        mProgressDlg?.show()
        Utils.hideSoftKeyboard(activity!!)
        getData()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode === Activity.RESULT_OK && requestCode === INVOICE_CODE_UPDATE) {
            mProgressDlg?.show()
            Utils.hideSoftKeyboard(activity!!)
            getData()
        }
    }

    private fun getData() {
        val fields = OdooFields()
        fields.addAll(
                "partner_id", "date_invoice", "number",
                "commercial_partner_id", "reference", "name",
                "journal_id", "company_id", "user_id",
                "date_due", "origin", "amount_total_signed",
                "residual_signed", "currency_id", "company_currency_id",
                "state", "type", "invoice_line_ids", "amount_untaxed", "amount_tax", "amount_total", "payment_ids"
        )
        val offset = 0
        val limit = 80
        val sorting = "date_invoice DESC"// DESC  ASC
        val domain = ODomain()
        domain.add("type", "=", "out_invoice")
        MyApplication.mClient?.searchRead(Constants.MODEL_ACCOUNT_INVOICE, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        if (mListData!!.size > 0) mListData?.clear()
                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<InvoicesModel>::class.java
                        )
                        mListData?.addAll(data)
                        activity!!.runOnUiThread {
                            if (mSwipeRefreshLayout.isRefreshing) {
                                mSwipeRefreshLayout.isRefreshing = false
                            }
                            mInvoicesAdapter?.notifyDataSetChanged()
                            mProgressDlg?.hide()
                        }
                    }
                })
    }

    override fun onInteraction(view: View, model: Any, position: Int) {
        val invoice = model as InvoicesModel
        val intent = Intent(activity, InvoicesDetailActivity::class.java)
        intent.putExtra(Constants.EXTRA_INVOICE, Gson().toJson(invoice))
        activity!!.startActivity(intent)
    }


    companion object {
        const val INVOICE_CODE_UPDATE = 222
    }
}
