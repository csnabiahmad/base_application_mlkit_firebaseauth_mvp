package appex.co.eastlog.view.activity

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.InventoryStockPickingAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.InventoryDashboardModel
import appex.co.eastlog.model.InventoryStockPickingModel
import appex.co.eastlog.utils.Utils
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_info_customer.mToolbar
import kotlinx.android.synthetic.main.activity_inventory_stock_picking.*
import kotlinx.android.synthetic.main.fragment_inventory.mSwipeRefreshLayout
import odoo.client.helper.OdooErrorException
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.listeners.IOdooResponse


class InventoryStockPickingActivity : AppCompatActivity(), AbstractAdapter.ListItemInteractionListener {

    private var mInventoryDashboardModel: InventoryDashboardModel? = null
    private var mInventoryStockPickingAdapter: InventoryStockPickingAdapter? = null
    private var mListData: ArrayList<InventoryStockPickingModel>? = null
    private var mProgressDlg: ProgressDlg? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory_stock_picking)

        setSupportActionBar(mToolbar)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        intent.extras.let {
            val data = it[EXTRAS_DASHBOARD_STOCK_PICKING]
            mInventoryDashboardModel = Gson().fromJson(data.toString(), InventoryDashboardModel::class.java)
            title = mInventoryDashboardModel?.warehouseId!![1].toString() + ": " + mInventoryDashboardModel?.name
        }
        mListData = ArrayList()
        mProgressDlg = ProgressDlg(this)

        mInventoryStockPickingAdapter = InventoryStockPickingAdapter(applicationContext, mListData)
        mInventoryStockPickingAdapter!!.setItemInteractionListener(this)

        val mLayoutManager = LinearLayoutManager(applicationContext)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewInventoryStockPicking.layoutManager = mLayoutManager
        mRecyclerViewInventoryStockPicking.setHasFixedSize(true)
        mRecyclerViewInventoryStockPicking.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewInventoryStockPicking.adapter = mInventoryStockPickingAdapter

        mSwipeRefreshLayout.setOnRefreshListener {
            getDataStockPickingFollowInventoryId()
        }

        mProgressDlg?.show()
        Utils.hideSoftKeyboard(this)
        /* get data */
        getDataStockPickingFollowInventoryId()
    }

    private fun getDataStockPickingFollowInventoryId() {
        val fields = OdooFields()
        fields.addAll(
                "id", "name", "location_dest_id", "partner_id", "date",
                "scheduled_date", "origin", "group_id", "backorder_id",
                "state", "priority", "picking_type_id"
        )
        val offset = 0
        val limit = 1000
        val sorting = ""
        val domain = ODomain()
        domain.add("picking_type_id", "=", mInventoryDashboardModel?.id)
        MyApplication.mClient?.searchRead(Constants.MODEL_STOCK_PICKING, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        Log.e("MODEL_STOCK_PICKING", Gson().toJson(result))
                        if (mListData!!.size > 0) mListData?.clear()
                        val data = Gson().fromJson(Gson().toJson(result!!.records), Array<InventoryStockPickingModel>::class.java)
                        mListData?.addAll(data)

                        runOnUiThread {
                            if (mSwipeRefreshLayout.isRefreshing) {
                                mSwipeRefreshLayout.isRefreshing = false
                            }
                            mInventoryStockPickingAdapter?.notifyDataSetChanged()
                            mProgressDlg?.hide()
                        }

                    }

                    override fun onError(error: OdooErrorException?): Boolean {
                        Log.e("MODEL_STOCK_PICKING ERROR ", error?.debugMessage)
                        return super.onError(error)
                    }
                })
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> {
                onBackPressed()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onInteraction(view: View, model: Any, position: Int) {

    }

    companion object {
        const val EXTRAS_DASHBOARD_STOCK_PICKING = "extras_dashboard_stock_picking"

        fun getStartIntent(context: Context, data: String): Intent {
            val intent = Intent(context, InventoryStockPickingActivity::class.java)
            intent.putExtra(EXTRAS_DASHBOARD_STOCK_PICKING, data)
            return intent
        }
    }
}
