package appex.co.eastlog.view.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.ProductAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.ProductModel
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_product.*
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.listeners.IOdooResponse

class ProductActivity : AppCompatActivity() , AbstractAdapter.ListItemInteractionListener  {

    private var mProgressDlg: ProgressDlg? = null
    private var mProductAdapter: ProductAdapter? = null
    private var mListData: ArrayList<ProductModel>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)

        setSupportActionBar(mToolbarProduct)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        title = "Product"

        mListData = ArrayList()

        mProductAdapter = ProductAdapter(applicationContext, mListData)
        mProductAdapter!!.setItemInteractionListener(this)

        val mLayoutManager = LinearLayoutManager(applicationContext)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewProduct.layoutManager = mLayoutManager
        mRecyclerViewProduct.setHasFixedSize(true)
        mRecyclerViewProduct.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewProduct.adapter = mProductAdapter

        mProgressDlg = ProgressDlg(this@ProductActivity)

        //search customer
        mSearchViewProduct.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextChange(newText: String?): Boolean {
                runOnUiThread {
                    mProductAdapter?.filter?.filter(newText)
                }
                return false
            }

            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

        })

        mSwipeRefreshLayout.setOnRefreshListener {
            fetchData()
        }
    }

    override fun onResume() {
        super.onResume()
        runOnUiThread {
            mProgressDlg?.show()
            fetchData()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> onBackPressed()
        }
        return super.onOptionsItemSelected(item)

    }

    override fun onInteraction(view: View, model: Any, position: Int) {
        val productModel = model as ProductModel
        val intent = Intent()
        intent.putExtra(Constants.EXTRA_PRODUCT, Gson().toJson(productModel))
        setResult(Activity.RESULT_OK, intent)
        finish()
    }


    fun fetchData() {
        val fields = OdooFields()
        fields.addAll(
                "id", "name", "categ_id", "services", "consumable",
                "filter_to_sell", "filter_to_purchase", "inactive", "attribute_line_ids", "pricelist_id",
                "activities_overdue", "activities_today", "activities_upcoming_all", "list_price",
                "image_medium", "type", "default_code", "standard_price", "qty_available", "virtual_available"
        )
        val offset = 0
        val limit = 80
        val sorting = "name DESC"
        val domain = ODomain()
        MyApplication.mClient?.searchRead(
                Constants.MODEL_PRODUCT_TEMPLATE, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        if (mListData!!.size > 0) mListData?.clear()

                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<ProductModel>::class.java
                        )
                        mListData?.addAll(data)

                        runOnUiThread {
                            if (mSwipeRefreshLayout.isRefreshing) {
                                mSwipeRefreshLayout.isRefreshing = false
                            }
                            mProductAdapter?.notifyDataSetChanged()
                            mProgressDlg?.hide()
                        }


                    }
                })
    }
}
