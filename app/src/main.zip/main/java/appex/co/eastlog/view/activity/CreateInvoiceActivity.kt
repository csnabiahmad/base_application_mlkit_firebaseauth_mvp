package appex.co.eastlog.view.activity

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DatePickerDialog
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.os.StrictMode
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.InvoiceLineAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.PopUpDlg
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.*
import appex.co.eastlog.utils.SharedPreference
import appex.co.eastlog.utils.Utils
import appex.co.eastlog.view.dialog.TaxesDialogFragment
import com.downloader.OnDownloadListener
import com.downloader.request.DownloadRequestBuilder
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_create_invoice.*
import odoo.client.helper.OdooErrorException
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.OArguments
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.helper.utils.OdooValues
import odoo.client.listeners.IOdooResponse
import org.apache.xmlrpc.client.XmlRpcClient
import org.apache.xmlrpc.client.XmlRpcClientConfigImpl
import pub.devrel.easypermissions.AfterPermissionGranted
import pub.devrel.easypermissions.EasyPermissions
import java.net.URL
import java.util.*


class CreateInvoiceActivity : AppCompatActivity(), AbstractAdapter.ListItemInteractionListener, EasyPermissions.PermissionCallbacks {

    private var mCustomer: Customer? = null
    private var mCustomerSale: Customer? = null
    private var mInvoiceDate: String? = null
    private var mDueDate: String? = null

    private var mCalendar: Calendar? = null
    private var mInvoiceLineAdapter: InvoiceLineAdapter? = null
    private var mListData: ArrayList<InvoiceLineModel>? = null

    private var mProgressDlg: ProgressDlg? = null
    private var mLocalData: SharedPreference? = null
    private var mListInvoiceLine = ArrayList<Int>()
    private var mInvoicesModel: InvoicesModel? = null
    private var mSharePdf: Boolean? = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_invoice)

        setSupportActionBar(mToolbarCreateInvoice)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        title = "Create Invoice"

        mListData = ArrayList()

        //number is null
        mTextViewNumber.visibility = View.GONE
        mRecyclerViewProduct.visibility = View.GONE

        mProgressDlg = ProgressDlg(this@CreateInvoiceActivity)
        mLocalData = SharedPreference.getInstance(this@CreateInvoiceActivity)

        mInvoiceLineAdapter = InvoiceLineAdapter(applicationContext, mListData)
        mInvoiceLineAdapter!!.setItemInteractionListener(this)

        val mLayoutManager = LinearLayoutManager(applicationContext)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewProduct.layoutManager = mLayoutManager
        mRecyclerViewProduct.setHasFixedSize(true)
        mRecyclerViewProduct.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewProduct.adapter = mInvoiceLineAdapter

        /* handler bundle activity */
        intent.let {
            val invoiceId = intent.getIntExtra(EXTRAS_INVOICE, 0)
            if (invoiceId != 0) {
                getInvoiceFromID(invoiceId)
                /* disable all button */
                mTextViewAddProduct.isEnabled = false
                mLinearLayoutCustomer.isEnabled = false
                mLinearLayoutInvoiceDate.isEnabled = false
                mLinearLayoutDueDate.isEnabled = false
                mLinearLayoutSalesperson.isEnabled = false
            } else {
                getSalesperson(MyApplication.getClient()?.user!!.uid)
            }
        }

        /* floating action button show menu */
        mFloatingActionMenu.setClosedOnTouchOutside(true)
        mFloatingActionMenu.setOnClickListener {
            if (mFloatingActionMenu.isOpened) {
                mFloatingActionMenu.close(true)
            }
        }
        //select customer
        mLinearLayoutCustomer.setOnClickListener {
            val intent = Intent(applicationContext, CustomerActivity::class.java)
            startActivityForResult(intent, CUSTOMER_RESULT_CODE)
        }

        //invoice date
        mTextViewInvoiceDate.text = Utils.dateToString(Calendar.getInstance().time, Constants.DATE_FORMAT_YYYY_MM_DD)
        mInvoiceDate = mTextViewInvoiceDate.text.toString()
        mLinearLayoutInvoiceDate.setOnClickListener {
            mCalendar = Calendar.getInstance()
            DatePickerDialog(
                    this@CreateInvoiceActivity, DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
                mCalendar!!.set(Calendar.YEAR, year)
                mCalendar!!.set(Calendar.MONTH, month)
                mCalendar!!.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                mTextViewInvoiceDate.text = Utils.dateToString(mCalendar?.time, Constants.DATE_FORMAT_YYYY_MM_DD)
                mInvoiceDate = Utils.dateToString(mCalendar?.time, Constants.DATE_FORMAT_YYYY_MM_DD)
            },
                    mCalendar!!.get(Calendar.YEAR),
                    mCalendar!!.get(Calendar.MONTH),
                    mCalendar!!.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        //due date
        mLinearLayoutDueDate.setOnClickListener {
            mCalendar = Calendar.getInstance()
            DatePickerDialog(
                    this@CreateInvoiceActivity, DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
                mCalendar!!.set(Calendar.YEAR, year)
                mCalendar!!.set(Calendar.MONTH, month)
                mCalendar!!.set(Calendar.DAY_OF_MONTH, dayOfMonth)
                mTextViewDueDate.text = Utils.dateToString(mCalendar?.time, Constants.DATE_FORMAT_YYYY_MM_DD)
                mDueDate = Utils.dateToString(mCalendar?.time, Constants.DATE_FORMAT_YYYY_MM_DD)
            },
                    mCalendar!!.get(Calendar.YEAR),
                    mCalendar!!.get(Calendar.MONTH),
                    mCalendar!!.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        //sales
        mLinearLayoutSalesperson.setOnClickListener {
            val intent = Intent(applicationContext, SalespersonActivity::class.java)
            startActivityForResult(intent, SALES_RESULT_CODE)
        }

        //add invoice line
        mTextViewAddProduct.setOnClickListener {
            val intent = Intent(applicationContext, ProductActivity::class.java)
            startActivityForResult(intent, PRODUCT_RESULT_CODE)
        }

        //save
        mTextViewSave.setOnClickListener {
            if (mCustomer == null) {
                Toast.makeText(applicationContext, "Please, You must first select a partner!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (mListData?.size == 0) {
                Toast.makeText(applicationContext, "Please create some invoice lines.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            mProgressDlg?.show()
            saveInvoice()
        }

        /* Send by Email */
        mFloatingActionButtonSendByEmail.setOnClickListener {
            mFloatingActionMenu.close(true)
            if (mCustomer == null) {
                Toast.makeText(applicationContext, "Please, You must first select a partner!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (mInvoicesModel == null) {
                Toast.makeText(applicationContext, "Please, click save order !!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val arguments = OArguments()
            arguments.add(listOf(mInvoicesModel?.id))
            MyApplication.mClient?.call_kw(
                    Constants.MODEL_ACCOUNT_INVOICE,
                    Constants.METHOD_ACTION_INVOICE_SENT,
                    arguments,
                    object : IOdooResponse() {
                        override fun onResult(result: OdooResult) {
                            mSharePdf = false
                            methodRequiresTwoPermission()
                        }
                    })
        }

        /* print */
        mFloatingActionButtonPrint.setOnClickListener {
            mFloatingActionMenu.close(true)
            if (mCustomer == null) {
                Toast.makeText(applicationContext, "Please, You must first select a partner!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (mInvoicesModel == null) {
                Toast.makeText(applicationContext, "Please Save Order !!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val arguments = OArguments()
            arguments.add(listOf(mInvoicesModel?.id))
            MyApplication.mClient?.call_kw(
                    Constants.MODEL_ACCOUNT_INVOICE,
                    Constants.METHOD_INVOICE_PRINT,
                    arguments,
                    object : IOdooResponse() {
                        override fun onResult(result: OdooResult) {
                            mSharePdf = true
                            methodRequiresTwoPermission()
                        }
                    })
        }

        /* validate */
        mFloatingActionButtonValidate.setOnClickListener {
            mFloatingActionMenu.close(true)
            if (mCustomer == null) {
                Toast.makeText(applicationContext, "Please, You must first select a partner!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (mInvoicesModel == null) {
                Toast.makeText(applicationContext, "Please Save Order !!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            val arguments = OArguments()
            arguments.add(listOf(mInvoicesModel?.id))
            MyApplication.mClient?.call_kw(
                    Constants.MODEL_ACCOUNT_INVOICE,
                    Constants.METHOD_ACTION_INVOICE_OPEN,
                    arguments,
                    object : IOdooResponse() {
                        override fun onResult(result: OdooResult) {
                            getInvoiceFromID(mInvoicesModel?.id!!)
                        }
                    })
        }

        /* register payment */
        mFloatingActionButtonRegisterPayment.setOnClickListener {
            mFloatingActionMenu.close(true)
            if (mCustomer == null) {
                Toast.makeText(applicationContext, "Please, You must first select a partner!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (mInvoicesModel == null) {
                Toast.makeText(applicationContext, "Please Save Order !!", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            runOnUiThread {
                mProgressDlg?.show()
                registerPayment(mInvoicesModel!!, mTextViewTotal.text.toString().replace(" $", "").toFloat()).execute()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == CUSTOMER_RESULT_CODE) {
            if (data != null) {
                val data = data.getStringExtra(Constants.EXTRA_CUSTOMER)
                mCustomer = Gson().fromJson(data.toString(), Customer::class.java)
                mTextViewCustomer.text = mCustomer?.displayName
            }
        } else if (resultCode == Activity.RESULT_OK && requestCode == SALES_RESULT_CODE) {
            if (data != null) {
                val data = data.getStringExtra(Constants.EXTRA_SALESPERSON)
                mCustomerSale = Gson().fromJson(data.toString(), Customer::class.java)
                mTextViewSale.text = mCustomerSale?.displayName
            }
        } else if (resultCode == Activity.RESULT_OK && requestCode == PRODUCT_RESULT_CODE) {
            if (data != null) {
                if (mRecyclerViewProduct.visibility == View.GONE) {
                    mRecyclerViewProduct.visibility = View.VISIBLE
                }
                val data = data.getStringExtra(Constants.EXTRA_PRODUCT)
                val product = Gson().fromJson(data.toString(), ProductModel::class.java)
                val invoiceLine = InvoiceLineModel()
                invoiceLine.quantity = 1
                invoiceLine.priceUnit = product.listPrice
                invoiceLine.name = product.name
                invoiceLine.productImage = product.imageMedium
                invoiceLine.id = product.id

                mListData?.add(invoiceLine)
                mInvoiceLineAdapter?.notifyDataSetChanged()
                updateTotal()
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> onBackPressed()
        }
        return super.onOptionsItemSelected(item)

    }

    override fun onInteraction(view: View, model: Any, position: Int) {
        val invoiceLineModel = model as InvoiceLineModel
        when (view.id) {
            R.id.mButtonDelete -> {
                val popUpDlg = PopUpDlg(this@CreateInvoiceActivity, false)
                popUpDlg.show("", getString(R.string.confirm_delete_item_product), getString(R.string.common_ok), getString(R.string.common_cancel),
                        DialogInterface.OnClickListener { dialog, whichButton ->
                            mListData?.removeAt(position)
                            mInvoiceLineAdapter?.notifyDataSetChanged()
                            if (mListData!!.size == 0) {
                                mRecyclerViewProduct.visibility = View.GONE
                            } else {
                                mRecyclerViewProduct.visibility = View.VISIBLE
                            }
                            updateTotal()
                            dialog.dismiss()
                        }, DialogInterface.OnClickListener { dialog, whichButton ->
                    dialog.dismiss()
                })
            }
            R.id.mButtonMinus -> {
                updateTotal()
            }
            R.id.mButtonPlus -> {
                updateTotal()
            }
            R.id.mTextViewTaxes -> {
                val taxesDialogFragment = TaxesDialogFragment()
                taxesDialogFragment?.setListener(object : TaxesDialogFragment.OnFragmentInteractionListener {
                    override fun onFragmentInteraction(taxes: String?) {
                        val taxes = Gson().fromJson<TaxesModel>(taxes, TaxesModel::class.java)
                        mListData!![position]!!.taxes = taxes
                        mInvoiceLineAdapter?.notifyItemChanged(position)
                        updateTotal()
                    }
                })
                taxesDialogFragment.show(supportFragmentManager.beginTransaction(), "")
            }
            else -> {
                updateTotal()
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        // EasyPermissions handles the request result.
        EasyPermissions.onRequestPermissionsResult(requestCode, permissions, grantResults, this);
    }

    override fun onPermissionsDenied(requestCode: Int, perms: MutableList<String>) {

    }

    override fun onPermissionsGranted(requestCode: Int, perms: MutableList<String>) {
        downloadFile(mSharePdf!!)
    }

    @AfterPermissionGranted(RC_CAMERA_AND_LOCATION)
    fun methodRequiresTwoPermission() {
        val perms = arrayOf<String>(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE)
        if (EasyPermissions.hasPermissions(applicationContext, *perms)) {
            downloadFile(mSharePdf!!)
        } else {
            // Do not have permissions, request them now
            EasyPermissions.requestPermissions(this@CreateInvoiceActivity, "Permission request!", RC_CAMERA_AND_LOCATION, *perms)
        }
    }

    private fun downloadFile(sharePdf: Boolean) {
        mProgressDlg?.show()
        val urlDownload = Constants.BASE_URL + Constants.URL_DOWNLOAD_INVOICE + mInvoicesModel?.id
        Log.e("urlDownload", urlDownload)
        var downloadFile = DownloadRequestBuilder(urlDownload, Utils.getFolder(),
                MyApplication.getClient()?.user!!.name + "_" + mInvoicesModel?.id + "_.pdf")
        downloadFile.setHeader(Constants.PARAM_COOKIE, Constants.PARAM_SESSION_ID + "=" + MyApplication.getClient()!!.sessionId)
        downloadFile.build().start(object : OnDownloadListener {

            override fun onError(error: com.downloader.Error?) {
                Log.e("error", error.toString())
                mProgressDlg?.hide()
                val popUpDlg = PopUpDlg(this@CreateInvoiceActivity, false)
                popUpDlg.show("", "Download error!", getString(R.string.common_ok), "",
                        DialogInterface.OnClickListener { dialog, whichButton ->
                            dialog.dismiss()
                        }, null)
            }

            override fun onDownloadComplete() {
                mProgressDlg?.hide()
                when (sharePdf) {
                    true -> {
                        Utils.shareFilePdf(Utils.getFolder() + "/" + MyApplication.getClient()?.user!!.name + "_" + mInvoicesModel?.id + "_.pdf", applicationContext)
                    }
                    else -> {
                        Utils.sendEmail(applicationContext, mCustomer?.email.toString(),
                                Utils.getFolder() + "/" + MyApplication.getClient()?.user!!.name + "_" + mInvoicesModel?.id + "_.pdf"
                                , Utils.getTitleEmail(mInvoicesModel!!)
                                , Utils.getSignatureEmail(MyApplication.mOwner!!)
                        )
                    }
                }
            }
        })
    }

    private fun updateStateInvoice(invoice: InvoicesModel) {
        mFloatingActionMenu.close(true)
        when (invoice.state) {
            "draft" -> {
                mTextViewDraft.setTextColor(ContextCompat.getColor(applicationContext, R.color.colorPrimary))
                mTextViewDraft.setBackgroundColor(ContextCompat.getColor(applicationContext, R.color.gray))

                mFloatingActionButtonSendByEmail.visibility = View.GONE
                mFloatingActionButtonPrint.visibility = View.GONE
                mFloatingActionButtonRegisterPayment.visibility = View.GONE
                mFloatingActionButtonValidate.visibility = View.VISIBLE

                /* visible edit */
                mTextViewSave.visibility = View.GONE
                mTextViewEdit.visibility = View.VISIBLE

            }
            "open" -> {
                mTextViewDraft.setTextColor(ContextCompat.getColor(applicationContext, R.color.colorPrimary))
                mTextViewDraft.setBackgroundColor(ContextCompat.getColor(applicationContext, R.color.gray))

                mTextViewOpen.setTextColor(ContextCompat.getColor(applicationContext, R.color.colorPrimary))
                mTextViewOpen.setBackgroundColor(ContextCompat.getColor(applicationContext, R.color.gray))

                mFloatingActionButtonSendByEmail.visibility = View.VISIBLE
                mFloatingActionButtonPrint.visibility = View.VISIBLE
                mFloatingActionButtonRegisterPayment.visibility = View.VISIBLE
                mFloatingActionButtonValidate.visibility = View.GONE

                /* visible edit */
                mTextViewSave.visibility = View.GONE
                mTextViewEdit.visibility = View.VISIBLE

            }
            "paid" -> {
                mTextViewDraft.setTextColor(ContextCompat.getColor(applicationContext, R.color.colorPrimary))
                mTextViewDraft.setBackgroundColor(ContextCompat.getColor(applicationContext, R.color.gray))

                mTextViewOpen.setTextColor(ContextCompat.getColor(applicationContext, R.color.colorPrimary))
                mTextViewOpen.setBackgroundColor(ContextCompat.getColor(applicationContext, R.color.gray))

                mTextViewPaid.setTextColor(ContextCompat.getColor(applicationContext, R.color.colorPrimary))
                mTextViewPaid.setBackgroundColor(ContextCompat.getColor(applicationContext, R.color.gray))

                mFloatingActionButtonSendByEmail.visibility = View.VISIBLE
                mFloatingActionButtonPrint.visibility = View.VISIBLE
                mFloatingActionButtonRegisterPayment.visibility = View.GONE
                mFloatingActionButtonValidate.visibility = View.GONE

                /* visible edit */
                mTextViewSave.visibility = View.GONE
                mTextViewEdit.visibility = View.GONE

            }
            "cancel" -> {

            }
        }
    }

    private fun saveInvoice() {
        val valuesInvoice = OdooValues()
        valuesInvoice.put(InvoicesModel.PARTNER_ID, mCustomer?.id)
        valuesInvoice.put(InvoicesModel.PAYMENT_TERM_ID, 1)
        valuesInvoice.put(InvoicesModel.STATE, "draft")
        valuesInvoice.put(InvoicesModel.DATE_INVOICE, mTextViewInvoiceDate.text)
        valuesInvoice.put(InvoicesModel.DATE_DUE, mTextViewDueDate.text)
        valuesInvoice.put(InvoicesModel.USER_ID, mCustomerSale?.id)
        valuesInvoice.put(InvoicesModel.AMOUNT_UNTAXED, mTextViewAmount.text.toString().replace(" $", ""))
        valuesInvoice.put(InvoicesModel.AMOUNT_TAX, mTextViewTax.text.toString().replace(" $", ""))
        valuesInvoice.put(InvoicesModel.AMOUNT_TOTAL, mTextViewTotal.text.toString().replace(" $", ""))

        MyApplication.mClient?.create(Constants.MODEL_ACCOUNT_INVOICE, valuesInvoice, object : IOdooResponse() {
            override fun onResult(result: OdooResult?) {
                runOnUiThread {
                    if (mListInvoiceLine.size > 0) mListInvoiceLine.clear()
                    val invoiceId = Math.round(result!!.getString("result").toFloat())
                    when (mListData?.size == 0) {
                        true -> {
                            mProgressDlg?.hide()
                            mTextViewSave.visibility = View.GONE
                            Toast.makeText(applicationContext, "Create Order Successfully!!", Toast.LENGTH_LONG).show()

                            /* update view if save successfully */
                            mInvoiceLineAdapter?.setReview(true)
                            mInvoiceLineAdapter?.notifyDataSetChanged()

                            /* visible edit */
                            mTextViewSave.visibility = View.GONE
                            mTextViewEdit.visibility = View.VISIBLE

                            /* disable all button */
                            mTextViewAddProduct.isEnabled = false
                            mLinearLayoutCustomer.isEnabled = false
                            mLinearLayoutInvoiceDate.isEnabled = false
                            mLinearLayoutDueDate.isEnabled = false
                            mLinearLayoutSalesperson.isEnabled = false

                            getInvoiceFromID(invoiceId)
                        }
                        else -> {
                            mListData?.forEachIndexed { index, productModel ->
                                /* submit tax total */
                                if (productModel.taxes != null) {
                                    val sum = productModel.priceUnit!! * productModel.quantity!!.toFloat()
                                    var tax = (productModel.taxes?.amount!! * sum) / 100

                                    val taxes = OdooValues()
                                    taxes.put(ProductModel.ACCOUNT_ID, MyApplication.mClient?.user!!.uid)
                                    taxes.put(ProductModel.TAX_ID, productModel.taxes?.id)
                                    taxes.put(ProductModel.INVOICE_ID, invoiceId)
                                    taxes.put(ProductModel.AMOUNT_TOTAL, "%.2f".format(tax))
                                    taxes.put(ProductModel.AMOUNT, "%.2f".format(tax))
                                    taxes.put(ProductModel.AMOUNT_ROUNDING, 0.0)
                                    taxes.put(ProductModel.DISPLAY_NAME, productModel.taxes?.displayName)
                                    taxes.put(ProductModel.NAME, productModel.taxes?.displayName)
                                    MyApplication.mClient?.create(
                                            Constants.MODEL_ACCOUNT_INVOICE_TAX,
                                            taxes,
                                            object : IOdooResponse() {
                                                override fun onResult(result: OdooResult?) {

                                                }

                                                override fun onError(error: OdooErrorException?): Boolean {
                                                    return true
                                                }
                                            })
                                }
                                sumbitAccountInvoiceLine(invoiceId, productModel).execute()
                            }
                        }
                    }
                }
            }
        })
    }

    private fun updateTotal() {
        var amount = 0f
        var tax = 0f

        mListData?.forEachIndexed { index, productModel ->
            val sum = productModel.priceUnit!! * productModel.quantity!!.toFloat()
            var tempTax = 0f
            if (productModel.taxes != null) {
                tempTax = (productModel.taxes?.amount!! * sum) / 100
            }
            amount += sum
            tax += tempTax
        }
        mTextViewAmount.text = "%.2f".format(amount) + " $"
        mTextViewTax.text = "%.2f".format(tax) + " $"
        mTextViewTotal.text = "%.2f".format(amount + tax) + " $"
    }

    @SuppressLint("StaticFieldLeak")
    inner class sumbitAccountInvoiceLine(val invoiceId: Int, val invoiceLine: InvoiceLineModel) : AsyncTask<Void, String, Int>() {

        private var mException: String? = null

        override fun doInBackground(vararg params: Void?): Int? {
            try {
                val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
                StrictMode.setThreadPolicy(policy)
                val client = XmlRpcClient()

                val commonConfig = XmlRpcClientConfigImpl()
                commonConfig.serverURL = URL(String.format(Constants.URL_COMMON, Constants.BASE_URL))
                commonConfig.isEnabledForExtensions = true
                commonConfig.isEnabledForExceptions = true

                val uid = client.execute(
                        commonConfig,
                        Constants.AUTHENTICATE,
                        Arrays.asList<Any>(
                                Constants.DATABASE,
                                mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_USERNAME),
                                mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_PASSWORD),
                                emptyMap<Any, Any>()
                        )
                ) as Int
                Log.e("uid", uid.toString() + "")
                val models = object : XmlRpcClient() {
                    init {
                        setConfig(object : XmlRpcClientConfigImpl() {
                            init {
                                serverURL = URL(String.format(Constants.URL_OBJECT, Constants.BASE_URL))
                            }
                        })
                    }
                }

                val idAccountInvoiceLine = models.execute(
                        "execute_kw",
                        Arrays.asList<Any>(Constants.DATABASE,
                                uid,
                                mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_PASSWORD),
                                Constants.MODEL_ACCOUNT_INVOICE_LINE,
                                "create",
                                Arrays.asList<Any>(object : java.util.HashMap<Any, Any>() {
                                    init {
                                        put(InvoiceLineModel.ACCOUNT_ID, MyApplication.mClient?.user!!.uid)
                                        put(InvoiceLineModel.PRODUCT_ID, invoiceLine.id!!.toInt())
                                        put(InvoiceLineModel.DESCRIPTION, invoiceLine.name!!)

                                        put(InvoiceLineModel.PRICE_UNIT, invoiceLine.priceUnit!!.toInt())
                                        put(InvoiceLineModel.QUANTITY, invoiceLine.quantity!!.toInt())
                                        put(InvoiceLineModel.PRICE_SUBTOTAL, (invoiceLine.priceUnit!! * invoiceLine.quantity!!).toInt())

                                        put(InvoiceLineModel.INVOICE_ID, invoiceId!!)
                                        if (invoiceLine.taxes != null) {
                                            put(InvoiceLineModel.INVOICE_LINE_TAX_IDS, Arrays.asList(Arrays.asList(4, (invoiceLine.taxes?.id?.toInt()), 0)))
                                        }
                                    }
                                })
                        )
                )
                return idAccountInvoiceLine as Int?
            } catch (e: Exception) {
                mException = e.toString()
            }
            return null
        }

        override fun onPostExecute(result: Int?) {
            if (mException != null || result == null) {
                Toast.makeText(applicationContext, mException, Toast.LENGTH_LONG).show()
                return
            }
            mListInvoiceLine.add(result)
            if (mListInvoiceLine.size == mListData?.size) {
                mProgressDlg?.hide()
                mTextViewSave.visibility = View.GONE
                mTextViewAddProduct.isEnabled = false
                mInvoiceLineAdapter?.setReview(true)
                mInvoiceLineAdapter?.notifyDataSetChanged()
                getInvoiceFromID(invoiceId)
            }
        }

    }

    private fun getInvoiceFromID(id: Int) {
        val fields = OdooFields()
        fields.addAll(
                "partner_id", "date_invoice", "number",
                "commercial_partner_id", "reference", "name",
                "journal_id", "company_id", "user_id",
                "date_due", "origin", "amount_total_signed",
                "residual_signed", "currency_id", "company_currency_id",
                "state", "type", "invoice_line_ids", "amount_untaxed", "amount_tax", "amount_total", "payment_ids", "product_image"
        )
        val offset = 0
        val limit = 1000
        val sorting = "name DESC"
        val domain = ODomain()
        domain.add(InvoicesModel.ID, "=", id)
        MyApplication.mClient?.searchRead(Constants.MODEL_ACCOUNT_INVOICE, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        val data = Gson().fromJson(Gson().toJson(result!!.records), Array<InvoicesModel>::class.java)
                        mInvoicesModel = data[0]
                        mTextViewNumber.text = mInvoicesModel?.number
                        title = when (Utils.getString(mInvoicesModel?.number).isEmpty()) {
                            true -> "Create Invoice"
                            else -> mInvoicesModel?.number
                        }
                        updateStateInvoice(mInvoicesModel!!)

                        mTextViewCustomer.text = mInvoicesModel?.partnerId!![1].toString()
                        mTextViewInvoiceDate.text = Utils.getString(mInvoicesModel?.dateInvoice)
                        mTextViewDueDate.text = Utils.getString(mInvoicesModel?.dateDue)
                        mTextViewSale.text = mInvoicesModel?.userId!![1].toString()

                        getInvoiceLineFromId(mInvoicesModel!!)
                        getCustomer(mInvoicesModel!!)
                    }
                })
    }

    private fun getInvoiceLineFromId(invoice: InvoicesModel) {
        val fields = OdooFields()
        fields.addAll(
                "sequence", "product_id", "origin",
                "is_rounding_line", "name", "company_id",
                "account_id", "account_analytic_id", "analytic_tag_ids",
                "quantity", "uom_id", "price_unit",
                "discount", "invoice_line_tax_ids", "price_subtotal", "currency_id", "product_image"
        )
        val offset = 0
        val limit = 1000
        val sorting = "name DESC"
        val domain = ODomain()
        domain.add(Constants.ID, "in", invoice?.invoiceLineIds)

        MyApplication.mClient?.searchRead(Constants.MODEL_ACCOUNT_INVOICE_LINE,
                domain,
                fields,
                offset,
                limit,
                sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        if (mListData?.size!! > 0) mListData?.clear()
                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<InvoiceLineModel>::class.java
                        )
                        mListData?.addAll(data)
                        runOnUiThread {
                            mInvoiceLineAdapter?.setReview(true)
                            mInvoiceLineAdapter?.notifyDataSetChanged()
                            if (mListData?.size == 0) {
                                mRecyclerViewProduct.visibility = View.GONE
                            } else {
                                mRecyclerViewProduct.visibility = View.VISIBLE
                            }
                        }
                    }
                })
    }

    private fun getSalesperson(id: Int) {
        val ids = Arrays.asList(id)
        val fields = Arrays.asList(
                "id", "color", "display_name", "title",
                "email", "parent_id", "is_company", "function", "phone",
                "street", "street2", "zip", "city", "country_id", "mobile", "state_id",
                "category_id", "image_small", "type", "website", "fax"
        )
        MyApplication.mClient?.read(
                Constants.MODEL_RES_USERS, ids, fields,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<Customer>::class.java
                        )
                        mCustomerSale = data[0]
                        mTextViewSale.text = mCustomerSale?.displayName
                    }
                })
    }

    private fun getCustomer(invoice: InvoicesModel) {
        val ids = Arrays.asList(invoice?.partnerId!![0].toString().toFloat().toInt())
        val fields = Arrays.asList(
                "id", "color", "display_name", "title",
                "email", "parent_id", "is_company", "function", "phone",
                "street", "street2", "zip", "city", "country_id", "mobile", "state_id",
                "category_id", "image_small", "type", "website", "fax"
        )

        MyApplication.mClient?.read(Constants.MODEL_RES_PARTNER, ids, fields,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<Customer>::class.java
                        )
                        mCustomer = data[0]
                    }
                })
    }

    @SuppressLint("StaticFieldLeak")
    inner class registerPayment(val invoicesModel: InvoicesModel, val total: Float) : AsyncTask<Void, String, Boolean>() {

        private var mException: String? = null

        override fun doInBackground(vararg params: Void?): Boolean? {
            var isSuccessfull = false
            try {
                val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
                StrictMode.setThreadPolicy(policy)
                val client = XmlRpcClient()

                val commonConfig = XmlRpcClientConfigImpl()
                commonConfig.serverURL = URL(String.format(Constants.URL_COMMON, Constants.BASE_URL))
                commonConfig.isEnabledForExtensions = true
                commonConfig.isEnabledForExceptions = true

                val uid = client.execute(
                        commonConfig,
                        Constants.AUTHENTICATE,
                        Arrays.asList<Any>(
                                Constants.DATABASE,
                                mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_USERNAME),
                                mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_PASSWORD),
                                emptyMap<Any, Any>()
                        )
                ) as Int
                Log.e("uid", uid.toString() + "")
                val models = object : XmlRpcClient() {
                    init {
                        setConfig(object : XmlRpcClientConfigImpl() {
                            init {
                                serverURL = URL(String.format(Constants.URL_OBJECT, Constants.BASE_URL))
                                isEnabledForExceptions = true
                                isEnabledForExtensions = true
                            }
                        })
                    }
                }

                val idPayment = models.execute(
                        "execute_kw", Arrays.asList<Any>(
                        Constants.DATABASE,
                        uid,
                        mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_PASSWORD),
                        "account.payment",
                        "create",
                        Arrays.asList<Any>(object : java.util.HashMap<Any, Any>() {
                            init {
                                put("invoice_ids", Arrays.asList(Arrays.asList(4, invoicesModel.id, 0)))
                                put("payment_method_id", 1)
                                put("payment_type", "inbound")
                                put("partner_type", "customer")
                                put("amount", total.toInt() + 1)
                                put("journal_id", 7)
                                put("partner_id", mCustomer?.id!!.toInt())
                                put("communication", invoicesModel?.number!!)
                                put("active_id", invoicesModel.id!!)
                                put("active_ids", invoicesModel?.id!!)
                                put("active_model", "account.invoice")
                                put("default_invoice_ids", Arrays.asList(Arrays.asList(4, invoicesModel.id!!, 0)))
                                put("uid", MyApplication.getClient()?.user!!.uid)
                            }
                        })
                )
                )
                Log.e("idPayment", idPayment.toString())
                isSuccessfull = models.execute("execute_kw", Arrays.asList<Any>(Constants.DATABASE, uid,
                        mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_PASSWORD),
                        "account.payment",
                        "action_validate_invoice_payment",
                        Arrays.asList(idPayment.toString().toInt())

                )) as Boolean

            } catch (e: Exception) {
                Log.e(">>>>>>>", e.toString())
                mException = e.toString()
            }
            return isSuccessfull
        }

        override fun onPostExecute(result: Boolean?) {
            mProgressDlg?.hide()
            if (!result!!) {
                Toast.makeText(applicationContext, mException, Toast.LENGTH_LONG).show()
                return
            }
            getInvoiceFromID(invoicesModel?.id!!)
        }
    }

    companion object {
        const val RC_CAMERA_AND_LOCATION = 4444
        const val CUSTOMER_RESULT_CODE = 1111
        const val SALES_RESULT_CODE = 2222
        const val PRODUCT_RESULT_CODE = 3333

        private const val EXTRAS_INVOICE = "extras_invoice"

        fun getStartIntent(context: Context, invoiceId: Int): Intent {
            val intent = Intent(context, CreateInvoiceActivity::class.java)
            intent.putExtra(EXTRAS_INVOICE, invoiceId)
            return intent
        }
    }

}
