package appex.co.eastlog.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.model.InventoryDashboardModel
import appex.co.eastlog.utils.Utils
import kotlinx.android.synthetic.main.layout_item_inventory_dashboard.view.*

class InventoryDashboardAdapter(private val mContext: Context, private var mListData: ArrayList<InventoryDashboardModel>?) : AbstractAdapter() {

    private var mItemInteractionListener: AbstractAdapter.ListItemInteractionListener? = null

    fun setItemInteractionListener(listener: AbstractAdapter.ListItemInteractionListener) {
        this.mItemInteractionListener = listener
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return InventoryDashBoardViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_item_inventory_dashboard, parent, false))
    }

    override fun getItemCount(): Int {
        return mListData!!.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val inventoryDashboard = mListData?.get(position)

        /* name */
        holder.itemView.mTextViewName.text = Utils.getString(inventoryDashboard?.name)

        /* ware house name */
        holder.itemView.mTextViewWarehouseName.text = Utils.getString(inventoryDashboard?.warehouseId!![1].toString())

        /* code */
        when (inventoryDashboard?.code) {
            "incoming" -> {
                holder.itemView.mTextViewCountPickingReady.text = inventoryDashboard?.countPickingReady.toString() + " To Receive"
            }
            else -> {
                holder.itemView.mTextViewCountPickingReady.text = inventoryDashboard?.countPickingReady.toString() + " To Do"
            }
        }
        holder.itemView.mTextViewCountPickingReady.setOnClickListener {
            mItemInteractionListener?.onInteraction(holder.itemView.mTextViewCountPickingReady, inventoryDashboard, position)
        }

        /* Waiting */
        when (inventoryDashboard?.countPickingWaiting == 0) {
            true -> {
                holder.itemView.mRelativeLayoutWaiting.visibility = View.GONE
            }
            else -> {
                holder.itemView.mRelativeLayoutWaiting.visibility = View.VISIBLE
                holder.itemView.mTextViewWaiting.text = inventoryDashboard?.countPickingWaiting.toString()
            }
        }

        /* Late */
        when (inventoryDashboard?.countPickingLate == 0) {
            true -> {
                holder.itemView.mRelativeLayoutLate.visibility = View.GONE
            }
            else -> {
                holder.itemView.mRelativeLayoutLate.visibility = View.VISIBLE
                holder.itemView.mTextViewLate.text = inventoryDashboard?.countPickingLate.toString()
            }
        }

        /* click item */
        holder.itemView.mLinearLayout.setOnClickListener {
            mItemInteractionListener?.onInteraction(holder.itemView, inventoryDashboard, position)
        }

    }


    class InventoryDashBoardViewHolder(view: View) : RecyclerView.ViewHolder(view)

}