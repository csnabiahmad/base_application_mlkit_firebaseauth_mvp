package appex.co.eastlog.common

object Constants {

    const val BASE_URL = "http://dev.appex.co:8069"
//    const val BASE_URL = "http://192.168.1.141:11000"

    const val URL_COMMON = "%s/xmlrpc/2/common"
    const val URL_OBJECT = "%s/xmlrpc/2/object"

    const val DATABASE = "appex"
//    const val DATABASE = "odoo11"

    const val CONTROLLER_CALL_BUTTON = "/web/dataset/call_button"
    const val CONTROLLER_CALL = "/web/dataset/call_kw"

    const val MODEL_RES_PARTNER = "res.partner"
    const val MODEL_RES_USERS = "res.users"
    const val MODEL_ACCOUNT_INVOICE = "account.invoice"
    const val MODEL_ACCOUNT_PAYMENT = "account.payment"
    const val MODEL_PRODUCT_TEMPLATE = "product.template"
    const val MODEL_ACCOUNT_INVOICE_LINE = "account.invoice.line"
    const val MODEL_ACCOUNT_TAX = "account.tax"
    const val MODEL_ACCOUNT_INVOICE_TAX = "account.invoice.tax"
    const val MODEL_PRODUCT_CATEGORY = "product.category"
    const val MODEL_STOCK_CHANGE_PRODUCT_QTY = "stock.change.product.qty"
    const val MODEL_STOCK_CHANGE_PRODUCT_QTY_CREATE = "$CONTROLLER_CALL/stock.change.product.qty/create"
    const val MODEL_STOCK_PICKING_TYPE = "stock.picking.type"
    const val MODEL_STOCK_PICKING = "stock.picking"

    const val AUTHENTICATE = "authenticate"

    const val METHOD_ACTION_INVOICE_OPEN = "action_invoice_open"
    const val METHOD_ACTION_VALIDATE_INVOICE_PAYMENT = "action_validate_invoice_payment"
    const val METHOD_ACTION_INVOICE_SENT = "action_invoice_sent"
    const val METHOD_INVOICE_PRINT = "invoice_print"

    const val PARTNER_ID = "partner_id"
    const val ID = "id"

    // API
    const val URL_DOWNLOAD_INVOICE = "/report/pdf/account.report_invoice/"
    const val URL_DOWNLOAD_SALES = "/report/pdf/sale.report_saleorder/"

    // API Parameter
    const val PARAM_COOKIE = "Cookie"
    const val PARAM_SESSION_ID = "session_id"

    // KEYs
    const val SHARED_PREFERENCES_KEY = "appex_shared_preference_key"
    const val SHARED_PREFERENCES_KEY_USERNAME = "appex_shared_preference_key_username"
    const val SHARED_PREFERENCES_KEY_PASSWORD = "appex_shared_preference_key_password"
    const val SHARED_PREFERENCES_KEY_TIME = "appex_shared_preference_key_time"

    //extra
    const val EXTRA_CUSTOMER = "appex_customer"
    const val EXTRA_INVOICE = "appex_invoice"
    const val EXTRA_SALESPERSON = "appex_salesperson"
    const val EXTRA_PRODUCT = "appex_product"
    const val EXTRA_IS_EDIT_CUSTOMER = "appex_is_edit_customer"


    //case screen position
    const val SCREEN_CUSTOMER = 0
    const val SCREEN_INVOICE = 1
    const val SCREEN_PRODUCT = 2
    const val SCREEN_INVENTORY = 3

    // Data format
    const val DATE_FORMAT_DEFAULT = "dd/MM/yyyy"
    const val DATE_FORMAT_YYYY_MM_DD = "yyyy-MM-dd"

}