package appex.co.eastlog.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable

class ProductCategoryModel :Serializable {
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("display_name")
    @Expose
    var displayName: String? = null
    @SerializedName("id")
    @Expose
    var id: Int? = null
}