package appex.co.eastlog.model

import java.io.Serializable
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TaxesModel : Serializable {
    @SerializedName("id")
    @Expose
    var id: Float? = null
    @SerializedName("amount")
    @Expose
    var amount: Float? = null
    @SerializedName("display_name")
    @Expose
    var displayName: String? = null
    @SerializedName("description")
    @Expose
    var description: String? = null
    @SerializedName("amount_type")
    @Expose
    var amountType: String? = null
}