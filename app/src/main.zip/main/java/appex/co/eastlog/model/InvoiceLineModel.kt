package appex.co.eastlog.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable


class InvoiceLineModel : Serializable {

    companion object {
        const val ACCOUNT_ID = "account_id"
        const val PRODUCT_ID = "product_id"
        const val DESCRIPTION = "name"
        const val PRICE_UNIT = "price_unit"
        const val QUANTITY = "quantity"
        const val PRICE_SUBTOTAL = "price_subtotal"
        const val INVOICE_ID = "invoice_id"
        const val INVOICE_LINE_TAX_IDS = "invoice_line_tax_ids"
    }

    @SerializedName("product_id")
    @Expose
    var productId: Any? = null
    @SerializedName("sequence")
    @Expose
    var sequence: Float? = null
    @SerializedName("analytic_tag_ids")
    @Expose
    var analyticTagIds: List<Any>? = null
    @SerializedName("is_rounding_line")
    @Expose
    var isRoundingLine: Boolean? = null
    @SerializedName("price_subtotal")
    @Expose
    var priceSubtotal: Float? = null
    @SerializedName("discount")
    @Expose
    var discount: Float? = null
    @SerializedName("invoice_line_tax_ids")
    @Expose
    var invoiceLineTaxIds: List<Int>? = null
    @SerializedName("quantity")
    @Expose
    var quantity: Int? = null
    @SerializedName("price_unit")
    @Expose
    var priceUnit: Float? = null
    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("company_id")
    @Expose
    var companyId: List<Any>? = null
    @SerializedName("origin")
    @Expose
    var origin: String? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("currency_id")
    @Expose
    var currencyId: List<Any>? = null
    @SerializedName("uom_id")
    @Expose
    var uomId: Any? = null
    @SerializedName("account_id")
    @Expose
    var accountId: List<Any>? = null
    @SerializedName("account_analytic_id")
    @Expose
    var accountAnalyticId: Boolean? = null
    @SerializedName("product_image")
    @Expose
    var productImage: String? = null

    var taxes: TaxesModel? = null
}