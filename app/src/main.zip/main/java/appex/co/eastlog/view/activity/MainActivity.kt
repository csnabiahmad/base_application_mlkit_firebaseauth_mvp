package appex.co.eastlog.view.activity

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Base64
import android.util.Log
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import appex.co.eastlog.R
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.PopUpDlg
import appex.co.eastlog.model.Customer
import appex.co.eastlog.presenter.MainPresenter
import appex.co.eastlog.utils.SharedPreference
import appex.co.eastlog.utils.Utils
import appex.co.eastlog.view.fragment.CustomerFragment
import com.bumptech.glide.Glide
import com.google.android.material.navigation.NavigationView
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.nav_header_main.view.*
import odoo.client.helper.data.OdooResult
import odoo.client.listeners.IOdooResponse
import java.util.*


class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private var mMainPresenter: MainPresenter? = null
    private var mFragment: Fragment? = null
    private var doubleBackToExitPressedOnce = false
    private var mLocalData: SharedPreference? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setSupportActionBar(mToolbarMain)
        supportActionBar!!.setDisplayShowTitleEnabled(false)
        val toggle = ActionBarDrawerToggle(
                this, mDrawerLayout, mToolbarMain, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        mDrawerLayout.addDrawerListener(toggle)
        toggle.syncState()


        mNavigationView.setNavigationItemSelectedListener(this)
        mMainPresenter = MainPresenter()
        mLocalData = SharedPreference.getInstance(applicationContext)

        //Default view show on app
        mFragment = CustomerFragment()
        val fragmentManager = supportFragmentManager
        fragmentManager.beginTransaction().replace(R.id.mContainer, mFragment!!, CustomerFragment::class.java!!.name)
                .commit()
        mTextViewTitle.text = getString(R.string.menu_customer)

        //TODO get user info
        mNavigationView.getHeaderView(0).mTextViewMainName.text = MyApplication.mClient?.user?.name.toString()
        mButtonLogout.setOnClickListener {
            PopUpDlg(this@MainActivity, false).show("", getString(R.string.menu_confirm_logout), getString(R.string.ok), getString(R.string.cancel),
                    DialogInterface.OnClickListener { dialog, whichButton ->
                        mLocalData?.removeAllData()
                        val intent = Intent(applicationContext, LoginActivity::class.java)
                        startActivity(intent)
                        finishAffinity()
                        dialog.dismiss()
                    },
                    DialogInterface.OnClickListener { dialog, whichButton ->
                        dialog.dismiss()
                    })
        }


        //get infor user
        getUserInfor()

    }

    override fun onResume() {
        super.onResume()
        /* dismiss keyboard */
        Utils.hideSoftKeyboard(this@MainActivity)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        for (fragment in supportFragmentManager.fragments) {
            fragment.onActivityResult(requestCode, resultCode, data)
        }
    }

    override fun onBackPressed() {
        if (mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            mDrawerLayout.closeDrawer(GravityCompat.START)
        } else {
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed()
                return
            }
            doubleBackToExitPressedOnce = true
            Toast.makeText(applicationContext, getString(R.string.confirm_logout), Toast.LENGTH_SHORT).show()
            Handler().postDelayed({ doubleBackToExitPressedOnce = false }, 2000)
        }
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        Utils.hideSoftKeyboard(this@MainActivity)
        when (item.itemId) {
            R.id.nav_customer -> {
                mTextViewTitle.text = item.title
                mMainPresenter!!.handlerMenuTabScreen(Constants.SCREEN_CUSTOMER, this@MainActivity, null)
            }
            R.id.nav_invoice -> {
                mTextViewTitle.text = item.title
                mMainPresenter!!.handlerMenuTabScreen(Constants.SCREEN_INVOICE, this@MainActivity, null)
            }
            R.id.nav_product -> {
                mTextViewTitle.text = item.title
                mMainPresenter!!.handlerMenuTabScreen(Constants.SCREEN_PRODUCT, this@MainActivity, null)
            }
            R.id.nav_inventory ->{
                mTextViewTitle.text = item.title
                mMainPresenter!!.handlerMenuTabScreen(Constants.SCREEN_INVENTORY, this@MainActivity, null)
            }
        }
        mDrawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun getUserInfor() {
        val ids = Arrays.asList(MyApplication.getClient()?.user!!.uid)
        val fields = Arrays.asList(
                "id", "color", "display_name", "title",
                "email", "parent_id", "is_company", "function", "phone",
                "street", "street2", "zip", "city", "country_id", "mobile", "state_id",
                "category_id", "image_small", "type", "website", "fax", "groups_id",
                "property_stock_customer", "property_stock_supplier"
        )
        MyApplication.mClient?.read(
                Constants.MODEL_RES_USERS, ids, fields,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        Log.e("MODEL_RES_USERS", Gson().toJson(result))
                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<Customer>::class.java
                        )
                        MyApplication.mOwner = data[0]
                        mNavigationView.getHeaderView(0).mTextViewMainEmail.text = MyApplication.mOwner?.email
                        if (MyApplication.mOwner?.imageSmall != "false") {
                            val imageByteArray = Base64.decode(MyApplication.mOwner?.imageSmall, 0)
                            Glide.with(applicationContext)
                                    .load(imageByteArray)
                                    .placeholder(R.drawable.icon_default)
                                    .into( mNavigationView.getHeaderView(0).mCircleImageViewAvatar)
                        }
                    }
                })
    }

}
