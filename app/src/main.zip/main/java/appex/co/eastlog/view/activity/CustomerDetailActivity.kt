package appex.co.eastlog.view.activity

import android.app.Activity
import android.content.DialogInterface
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import appex.co.eastlog.R
import appex.co.eastlog.adapter.ViewPagerAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.PopUpDlg
import appex.co.eastlog.model.Customer
import appex.co.eastlog.utils.Utils
import appex.co.eastlog.view.fragment.BlankFragment
import appex.co.eastlog.view.fragment.CustomerFragment
import appex.co.eastlog.view.fragment.customer.InfoCustomerFragment
import appex.co.eastlog.viewmodel.CustomerViewModel
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_customer_detail.*
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.OdooValues
import odoo.client.listeners.IOdooResponse


class CustomerDetailActivity : AppCompatActivity() {

    private var mCustomer: Customer? = null
    private var isEditCustomer: Boolean = false
    private var isChange: Boolean = false
    private var mViewPagerAdapter: ViewPagerAdapter? = null
    private var mCustomerViewModel: CustomerViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer_detail)

        setSupportActionBar(mToolbarProfile)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        supportActionBar!!.setDisplayShowTitleEnabled(false)

        mCustomerViewModel = ViewModelProviders.of(this)[CustomerViewModel::class.java]
        mCustomerViewModel?.getCustomer()?.observe(this, Observer<Customer> {
        })

        intent.extras.let {
            isEditCustomer = it[Constants.EXTRA_IS_EDIT_CUSTOMER] as Boolean
            if (isEditCustomer) {

                val data = it[Constants.EXTRA_CUSTOMER]
                mCustomer = Gson().fromJson(data.toString(), Customer::class.java)
                mCustomerViewModel?.setCustomer(mCustomer!!)

                // display view
                mLinearLayoutStatus.visibility = View.VISIBLE
                mTextViewSave.text = getString(R.string.edit)
                mTextViewName.text = Utils.getString(mCustomer?.displayName)
                mTextViewOpportunities.text = mCustomer?.opportunityCount.toString()
                mTextViewMeeting.text = mCustomer?.meetingCount.toString()
                mTextViewSale.text = mCustomer?.saleOrderCount.toString()
                mTextViewInvoiced.text = mCustomer?.totalInvoiced.toString()

                supportPostponeEnterTransition()
                if (mCustomer?.imageSmall != "false") {
                    val imageByteArray = Base64.decode(mCustomer?.imageSmall, 0)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        val imageTransitionName = it.getString(CustomerFragment.EXTRA_ANIMAL_IMAGE_TRANSITION_NAME)
                        mCircleImageViewAvatar.transitionName = imageTransitionName
                    }
                    Glide.with(applicationContext)
                            .load(imageByteArray)
                            .addListener(object : RequestListener<Drawable> {
                                override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>?, isFirstResource: Boolean): Boolean {
                                    supportStartPostponedEnterTransition()
                                    return false
                                }

                                override fun onResourceReady(resource: Drawable?, model: Any?, target: Target<Drawable>?, dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                                    supportStartPostponedEnterTransition()
                                    return false
                                }
                            })
                            .into(mCircleImageViewAvatar)

                } else {
                    Glide.with(applicationContext)
                            .load(R.drawable.icon_default)
                            .addListener(object : RequestListener<Drawable> {
                                override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>?, isFirstResource: Boolean): Boolean {
                                    supportStartPostponedEnterTransition()
                                    return false
                                }

                                override fun onResourceReady(resource: Drawable?, model: Any?, target: Target<Drawable>?, dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                                    supportStartPostponedEnterTransition()
                                    return false
                                }
                            })
                            .into(mCircleImageViewAvatar)
                }
            } else {
                mCustomer = Customer()
                mCustomerViewModel?.setCustomer(mCustomer!!)
                mLinearLayoutStatus.visibility = View.GONE
                Glide.with(applicationContext)
                        .load(R.drawable.icon_default)
                        .addListener(object : RequestListener<Drawable> {
                            override fun onLoadFailed(e: GlideException?, model: Any?, target: Target<Drawable>?, isFirstResource: Boolean): Boolean {
                                supportStartPostponedEnterTransition()
                                return false
                            }

                            override fun onResourceReady(resource: Drawable?, model: Any?, target: Target<Drawable>?, dataSource: DataSource?, isFirstResource: Boolean): Boolean {
                                supportStartPostponedEnterTransition()
                                return false
                            }
                        })
                        .into(mCircleImageViewAvatar)
            }
        }

        mViewPagerAdapter = ViewPagerAdapter(applicationContext, supportFragmentManager)
        mViewPagerAdapter?.addFragment(InfoCustomerFragment(), "Info")
        mViewPagerAdapter?.addFragment(BlankFragment(), "Contacts & Addresses")
        mViewPagerAdapter?.addFragment(BlankFragment(), "Sales & Purchases")
        mViewPagerAdapter?.addFragment(BlankFragment(), "Invoicing")
        mLockableViewPager.adapter = mViewPagerAdapter
        mTabLayoutInfo.setupWithViewPager(mLockableViewPager)

        /* save */
        mTextViewSave.setOnClickListener {
            if (mTextViewSave.text == getString(R.string.save)) {
                val customer = (mViewPagerAdapter?.getItem(0) as InfoCustomerFragment).getCustomer()
                mCustomerViewModel?.getCustomer()!!.value?.displayName = customer.displayName
                mCustomerViewModel?.getCustomer()!!.value?.street = customer.street
                mCustomerViewModel?.getCustomer()!!.value?.street2 = customer.street2
                mCustomerViewModel?.getCustomer()!!.value?.city = customer.city
                mCustomerViewModel?.getCustomer()!!.value?.zip = customer.zip
                mCustomerViewModel?.getCustomer()!!.value?.countryId = customer.countryId
                mCustomerViewModel?.getCustomer()!!.value?.phone = customer.phone
                mCustomerViewModel?.getCustomer()!!.value?.mobile = customer.mobile
                mCustomerViewModel?.getCustomer()!!.value?.email = customer.email
                mCustomerViewModel?.getCustomer()!!.value?.website = customer.website
                saveCustomer()
                return@setOnClickListener
            }
            (mViewPagerAdapter?.getItem(0) as InfoCustomerFragment).updateViewInput(true)
            mTextViewSave.text = getString(R.string.save)
        }

        /* click invoiced */
        mLinearLayoutInvoiced.setOnClickListener {
            val intent = Intent(applicationContext, MyInvoicesActivity::class.java)
            intent.putExtra(Constants.EXTRA_CUSTOMER, Gson().toJson(mCustomer))
            intent.putExtra(Constants.EXTRA_IS_EDIT_CUSTOMER, true)
            startActivity(intent)
        }

    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> {
                if (isChange) {
                    setResult(Activity.RESULT_OK, Intent())
                    finish()
                } else {
                    onBackPressed()
                }
            }
        }
        return super.onOptionsItemSelected(item)

    }

    private fun saveCustomer() {
        Utils.hideSoftKeyboard(this@CustomerDetailActivity)
        val username = mCustomerViewModel?.getCustomer()?.value?.displayName.toString()
        val mobile = mCustomerViewModel?.getCustomer()?.value?.mobile.toString()
        val phone = mCustomerViewModel?.getCustomer()?.value?.phone.toString()
        val email = mCustomerViewModel?.getCustomer()?.value?.email.toString()
        val street = mCustomerViewModel?.getCustomer()?.value?.street.toString()
        val street2 = mCustomerViewModel?.getCustomer()?.value?.street2.toString()
        val city = mCustomerViewModel?.getCustomer()?.value?.city.toString()
        val zip = mCustomerViewModel?.getCustomer()?.value?.zip.toString()
        val website = mCustomerViewModel?.getCustomer()?.value?.website.toString()

        if (username.isEmpty()) {
            Toast.makeText(applicationContext, getString(R.string.error_name_required), Toast.LENGTH_LONG).show()
            return
        }
        val values = OdooValues()
        values.put(Customer.NAME, username)
        values.put(
                Customer.MOBILE, when (mobile.isEmpty()) {
            true -> ""
            else -> mobile
        }
        )
        values.put(
                Customer.PHONE, when (phone.isEmpty()) {
            true -> ""
            else -> phone
        }
        )
        values.put(
                Customer.EMAIL, when (email.isEmpty()) {
            true -> ""
            else -> email
        }
        )
        values.put(
                Customer.STREET, when (street.isEmpty()) {
            true -> ""
            else -> street
        }
        )
        values.put(
                Customer.STREET2, when (street2.isEmpty()) {
            true -> ""
            else -> street2
        }
        )
        values.put(
                Customer.CITY, when (city.isEmpty()) {
            true -> ""
            else -> city
        }
        )
        values.put(
                Customer.ZIP, when (zip.isEmpty()) {
            true -> ""
            else -> zip
        }
        )
        values.put(
                Customer.WEBSITE, when (website.isEmpty()) {
            true -> ""
            else -> website
        }
        )

        if (isEditCustomer) {
            MyApplication.mClient?.write(
                    Constants.MODEL_RES_PARTNER,
                    arrayOf(mCustomer?.id!!.toInt()),
                    values,
                    object : IOdooResponse() {
                        override fun onResult(result: OdooResult?) {
                            isChange = true
                            Toast.makeText(applicationContext, getString(R.string.update_customer), Toast.LENGTH_LONG).show()
                            mTextViewSave.text = getString(R.string.edit)
                            (mViewPagerAdapter?.getItem(0) as InfoCustomerFragment).updateViewInput(false)
                        }
                    })
        } else {
            MyApplication.mClient?.create(Constants.MODEL_RES_PARTNER, values, object : IOdooResponse() {
                override fun onResult(result: OdooResult?) {
                    runOnUiThread {
                        val popUpDlg = PopUpDlg(this@CustomerDetailActivity, false)
                        popUpDlg.show("", getString(R.string.create_customer), getString(R.string.common_ok), "",
                                DialogInterface.OnClickListener { dialog, whichButton ->
                                    dialog.dismiss()
                                    setResult(Activity.RESULT_OK, Intent())
                                    finish()
                                }, null)
                    }
                }
            })
        }
    }
}
