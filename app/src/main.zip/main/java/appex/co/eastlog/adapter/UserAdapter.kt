package appex.co.eastlog.adapter

import android.content.Context
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.model.Customer
import appex.co.eastlog.utils.Utils
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.layout_item_customer.view.*


class UserAdapter(private val mContext: Context, private var mListData: ArrayList<Customer>?) :
        AbstractAdapter(), Filterable {

    private var mListDataFull: ArrayList<Customer>? = null
    private var mItemInteractionListener: AbstractAdapter.ListItemInteractionListener? = null
    /**
     * @param listener
     */
    fun setItemInteractionListener(listener: AbstractAdapter.ListItemInteractionListener) {
        this.mItemInteractionListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        mListDataFull = ArrayList()
        mListDataFull?.addAll(mListData!!)
        return CustomerViewHolder(
                LayoutInflater.from(mContext).inflate(R.layout.layout_item_user, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return mListData!!.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val customer = mListData?.get(position)

        /**
         * avatar
         */
        if (customer?.imageSmall != "false") {
            val imageByteArray =
                    Base64.decode(customer?.imageSmall, 0)
            Glide.with(mContext)
                    .load(imageByteArray)
                    .placeholder(R.drawable.icon_default)
                    .into(holder.itemView.mImageViewAvatar)
        } else {
            Glide.with(mContext)
                    .load(R.drawable.icon_placeholder)
                    .placeholder(R.drawable.icon_placeholder)
                    .error(R.drawable.icon_placeholder)
                    .into(holder.itemView.mImageViewAvatar)
        }

        /**
         * display name
         */
        holder.itemView.mTextViewName.text = customer?.displayName ?: ""

        /**
         * quantity
         */
        holder.itemView.mTextViewEmail.text = Utils.getString(customer?.email)
        holder.itemView.mLinearLayout.setOnClickListener {
            if (mItemInteractionListener != null) {
                mItemInteractionListener?.onInteraction(holder.itemView, customer!!, position)
            }
        }
    }

    override fun getFilter(): Filter {
        return customerFilter
    }

    class CustomerViewHolder(view: View) : RecyclerView.ViewHolder(view)

    private val customerFilter = object : Filter() {
        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val filteredList = ArrayList<Customer>()

            if (constraint == null || constraint.isEmpty()) {
                filteredList.addAll(mListDataFull!!)
            } else {
                val filterPattern = constraint.toString().toLowerCase().trim()

                for (item in mListDataFull!!) {
                    if (item.displayName!!.toLowerCase().contains(filterPattern)) {
                        filteredList.add(item)
                    }
                }
            }
            val results = FilterResults()
            results.values = filteredList

            return results
        }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            if (results!!.values == null) return
            mListData?.clear()
            mListData?.addAll(results!!.values as ArrayList<Customer>)
            notifyDataSetChanged()
        }
    }
}