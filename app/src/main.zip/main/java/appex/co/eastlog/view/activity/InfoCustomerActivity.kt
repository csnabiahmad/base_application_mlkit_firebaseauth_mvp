//package appex.co.eastlog.view.activity
//
//import android.app.Activity
//import android.content.Context
//import android.content.Intent
//import android.os.Bundle
//import android.view.MenuItem
//import androidx.appcompat.app.AppCompatActivity
//import appex.co.eastlog.R
//import appex.co.eastlog.model.Customer
//import appex.co.eastlog.utils.Utils
//import appex.co.eastlog.view.fragment.customer.InfoCustomerFragment
//import com.google.gson.Gson
//import kotlinx.android.synthetic.main.activity_info_customer.*
//
//class InfoCustomerActivity : AppCompatActivity() {
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_info_customer)
//
//        setSupportActionBar(mToolbar)
//        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
//        supportActionBar!!.setDisplayShowHomeEnabled(true)
//        supportActionBar!!.setDisplayShowTitleEnabled(false)
//
//        /* handler bundle activity */
//        intent.let {
//            when (intent.getStringExtra(EXTRAS_POSITION_EDIT)) {
//                "Name" -> {
//                    mTextInputEditTextName.requestFocus()
//                }
//                "Street..." -> {
//                    mTextInputEditTextStreet.requestFocus()
//                }
//                "Street 2..." -> {
//                    mTextInputEditTextStreet2.requestFocus()
//                }
//                "City" -> {
//                    mTextInputEditTextCity.requestFocus()
//                }
//                "ZIP" -> {
//                    mTextInputEditTextZip.requestFocus()
//                }
//                "Country" -> {
//                    mTextInputEditTextCountry.requestFocus()
//                }
//                "Phone" -> {
//                    mTextInputEditTextPhone.requestFocus()
//                }
//                "Mobile" -> {
//                    mTextInputEditTextMobile.requestFocus()
//                }
//                "Email" -> {
//                    mTextInputEditTextEmail.requestFocus()
//                }
//                else -> {
//                    mTextInputEditTextWebsite.requestFocus()
//                }
//            }
//
//            val customer  = Gson().fromJson<Customer>(intent.getStringExtra(EXTRAS_DATA),Customer::class.java)
//            mTextInputEditTextName.setText(Utils.getString(customer?.displayName))
//            mTextInputEditTextMobile.setText(Utils.getString(customer?.mobile))
//            mTextInputEditTextPhone.setText(Utils.getString(customer?.phone))
//            mTextInputEditTextEmail.setText(Utils.getString(customer?.email))
//            mTextInputEditTextStreet.setText(Utils.getString(customer?.street))
//            mTextInputEditTextStreet2.setText(Utils.getString(customer?.street2))
//            mTextInputEditTextCity.setText(Utils.getString(customer?.city))
//            mTextInputEditTextZip.setText(Utils.getString(customer?.zip))
//            mTextInputEditTextWebsite.setText(Utils.getString(customer?.website))
//            mTextInputEditTextCountry.setText(Utils.getString(customer?.countryId.toString()))
//        }
//
//        mTextViewSave.setOnClickListener {
//            val customer = Customer()
//            customer.displayName = mTextInputEditTextName.text.toString()
//            customer.street = mTextInputEditTextStreet.text.toString()
//            customer.street2 = mTextInputEditTextStreet2.text.toString()
//            customer.city = mTextInputEditTextCity.text.toString()
//            customer.zip = mTextInputEditTextZip.text.toString()
//            customer.countryId = mTextInputEditTextCountry.text.toString()
//            customer.phone = mTextInputEditTextPhone.text.toString()
//            customer.mobile = mTextInputEditTextMobile.text.toString()
//            customer.email = mTextInputEditTextEmail.text.toString()
//            customer.website = mTextInputEditTextWebsite.text.toString()
//
//            val returnIntent = Intent()
//            returnIntent.putExtra(InfoCustomerFragment.EXTRAS_INFO_CUSTOMER, Gson().toJson(customer))
//            setResult(Activity.RESULT_OK, returnIntent)
//            finish()
//        }
//
//    }
//
//    override fun onBackPressed() {
//        super.onBackPressed()
//    }
//
//    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
//        when (item?.itemId) {
//            android.R.id.home -> {
//                onBackPressed()
//            }
//        }
//        return super.onOptionsItemSelected(item)
//    }
//
//    companion object {
//        const val EXTRAS_POSITION_EDIT = "extras_position_edit"
//        const val EXTRAS_DATA = "extras_data"
//
//        fun getStartIntent(context: Context, position: String, data: String?): Intent {
//            val intent = Intent(context, InfoCustomerActivity::class.java)
//            intent.putExtra(EXTRAS_POSITION_EDIT, position)
//            intent.putExtra(EXTRAS_DATA, data)
//            return intent
//        }
//    }
//
//}
