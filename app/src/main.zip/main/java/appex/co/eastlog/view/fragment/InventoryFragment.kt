package appex.co.eastlog.view.fragment


import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.InventoryDashboardAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.InventoryDashboardModel
import appex.co.eastlog.utils.Utils
import appex.co.eastlog.view.activity.InventoryStockPickingActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_inventory.*
import odoo.client.helper.OdooErrorException
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.listeners.IOdooResponse

class InventoryFragment : Fragment(), AbstractAdapter.ListItemInteractionListener {

    private var mProgressDlg: ProgressDlg? = null
    private var mInventoryDashboardAdapter: InventoryDashboardAdapter? = null
    private var mListData: ArrayList<InventoryDashboardModel>? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_inventory, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mListData = ArrayList()
        mProgressDlg = ProgressDlg(activity)

        mInventoryDashboardAdapter = InventoryDashboardAdapter(activity!!, mListData)
        mInventoryDashboardAdapter!!.setItemInteractionListener(this)

        val mLayoutManager = LinearLayoutManager(activity!!)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewInventory.layoutManager = mLayoutManager
        mRecyclerViewInventory.setHasFixedSize(true)
        mRecyclerViewInventory.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewInventory.adapter = mInventoryDashboardAdapter

        mSwipeRefreshLayout.setOnRefreshListener {
            fetchDataInventory()
        }

        mProgressDlg?.show()
        Utils.hideSoftKeyboard(activity!!)
        /* get dashboard inventory */
        fetchDataInventory()
    }


    private fun fetchDataInventory() {
        val fields = OdooFields()
        fields.addAll(
                "id", "color", "code", "count_picking_ready",
                "count_picking_draft", "count_picking_waiting", "count_picking_late",
                "count_picking_backorders", "name", "warehouse_id"
        )
        val offset = 0
        val limit = 80
        val sorting = ""
        val domain = ODomain()
        MyApplication.mClient?.searchRead(Constants.MODEL_STOCK_PICKING_TYPE, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
//                        Log.e("MODEL_STOCK_PICKING_TYPE", Gson().toJson(result))
                        if (mListData!!.size > 0) mListData?.clear()

                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<InventoryDashboardModel>::class.java
                        )
                        mListData?.addAll(data)

                        activity!!.runOnUiThread {
                            if (mSwipeRefreshLayout.isRefreshing) {
                                mSwipeRefreshLayout.isRefreshing = false
                            }
                            mInventoryDashboardAdapter?.notifyDataSetChanged()
                            mProgressDlg?.hide()
                        }

                    }

                    override fun onError(error: OdooErrorException?): Boolean {
                        Log.e("MODEL_STOCK_PICKING_TYPE ERROR ", error?.debugMessage)
                        return super.onError(error)
                    }
                })
    }


    override fun onInteraction(view: View, model: Any, position: Int) {
        val inventoryDashboardModel = model as InventoryDashboardModel

        val intent = InventoryStockPickingActivity.getStartIntent(activity!!, Gson().toJson(inventoryDashboardModel))
        startActivity(intent)
    }


}
