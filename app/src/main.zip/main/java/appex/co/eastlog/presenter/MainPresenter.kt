package appex.co.eastlog.presenter

import android.os.Bundle
import androidx.fragment.app.Fragment
import appex.co.eastlog.R
import appex.co.eastlog.common.Constants
import appex.co.eastlog.view.activity.MainActivity
import appex.co.eastlog.view.fragment.CustomerFragment
import appex.co.eastlog.view.fragment.InventoryFragment
import appex.co.eastlog.view.fragment.InvoicesFragment
import appex.co.eastlog.view.fragment.ProductFragment

class MainPresenter {

    var mFragment: Fragment? = null

    /**
     * handler menu tab
     *
     * @param position
     * @param activity
     */
    fun handlerMenuTabScreen(position: Int, activity: MainActivity, value: Any?) {
        var fragmentClass: Class<*>? = null
        var bundle: Bundle? = null
        mFragment = null
        when (position) {
            Constants.SCREEN_CUSTOMER -> {
                bundle = Bundle()
                fragmentClass = CustomerFragment::class.java
            }
            Constants.SCREEN_INVOICE -> {
                bundle = Bundle()
                fragmentClass = InvoicesFragment::class.java
            }
            Constants.SCREEN_PRODUCT -> {
                bundle = Bundle()
                fragmentClass = ProductFragment::class.java
            }
            Constants.SCREEN_INVENTORY -> {
                bundle = Bundle()
                fragmentClass = InventoryFragment::class.java
            }

            else -> fragmentClass = null
        }
        if (fragmentClass != null) {
            try {
                val myFragment = activity.supportFragmentManager.findFragmentByTag(fragmentClass.name)
                if (myFragment != null && myFragment.isVisible) {
                    return
                }
                mFragment = fragmentClass.newInstance() as Fragment
                if (bundle != null) {
                    mFragment?.arguments = bundle
                }
                val fragmentManager = activity.supportFragmentManager
                fragmentManager.beginTransaction().replace(R.id.mContainer, mFragment!!, fragmentClass.name).commit()
            } catch (e: Exception) {
                e.printStackTrace()
            }

        }
    }
}