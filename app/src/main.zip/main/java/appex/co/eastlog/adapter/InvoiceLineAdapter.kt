package appex.co.eastlog.adapter

import android.content.Context
import android.util.Base64
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.model.InvoiceLineModel
import appex.co.eastlog.model.TaxesModel
import appex.co.eastlog.utils.Utils
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.google.gson.Gson
import kotlinx.android.synthetic.main.layout_item_invoice_line.view.*
import odoo.client.helper.data.OdooResult
import odoo.client.listeners.IOdooResponse
import java.util.*

class InvoiceLineAdapter(private val mContext: Context, private var mListData: java.util.ArrayList<InvoiceLineModel>?) :
        AbstractAdapter() {

    private var mItemInteractionListener: AbstractAdapter.ListItemInteractionListener? = null
    private var mIsReview: Boolean? = false

    /**
     * @param listener
     */
    fun setItemInteractionListener(listener: AbstractAdapter.ListItemInteractionListener) {
        this.mItemInteractionListener = listener
    }

    fun setReview(review: Boolean) {
        this.mIsReview = review
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return InvoicesViewHolder(
                LayoutInflater.from(mContext).inflate(R.layout.layout_item_invoice_line, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return mListData!!.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val invoiceLineModel = mListData?.get(position)

        if (Utils.getString(invoiceLineModel?.productImage).isNotBlank()) {
            val imageByteArray = Base64.decode(invoiceLineModel?.productImage, 0)
            Glide.with(mContext)
                    .load(imageByteArray)
                    .error(R.drawable.icon_placeholder)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .dontAnimate()
                    .into(holder.itemView.mImageViewAvatar)
        }else {
            Glide.with(mContext)
                    .load(R.drawable.icon_placeholder)
                    .placeholder(R.drawable.icon_placeholder)
                    .error(R.drawable.icon_placeholder)
                    .into(holder.itemView.mImageViewAvatar)
        }

        /* display name */
        holder.itemView.mTextViewName.text = Utils.getString(invoiceLineModel?.name)

        /* quantity */
        holder.itemView.mTextViewOrderedQty.text = invoiceLineModel?.quantity.toString()

        /* price */
        holder.itemView.mTextViewPrice.text = "Price: $ " + Utils.getString(invoiceLineModel?.priceUnit.toString())

        /* taxes */
        if (invoiceLineModel?.taxes != null) {
            holder.itemView.mTextViewTaxes.text = Utils.getString(invoiceLineModel?.taxes?.displayName)
        } else {
            if (invoiceLineModel?.invoiceLineTaxIds != null && invoiceLineModel?.invoiceLineTaxIds!!.size > 0) {
                val fields = Arrays.asList("id", "display_name", "description", "amount", "amount_type")
                MyApplication.mClient?.read(Constants.MODEL_ACCOUNT_TAX, invoiceLineModel.invoiceLineTaxIds!!, fields,
                        object : IOdooResponse() {
                            override fun onResult(result: OdooResult?) {
                                Log.e("MODEL_ACCOUNT_TAX", Gson().toJson(result))
                                val data = Gson().fromJson(
                                        Gson().toJson(result!!.records),
                                        Array<TaxesModel>::class.java
                                )
                                invoiceLineModel.taxes = data[0]
                                holder.itemView.mTextViewTaxes.text = Utils.getString(invoiceLineModel?.taxes?.displayName)
                                /* update amount, tax, total */
                                mItemInteractionListener?.onInteraction(holder.itemView, invoiceLineModel!!, position)
                            }
                        })
            }
        }
        if (position == mListData?.size!! - 1) {
            mItemInteractionListener?.onInteraction(holder.itemView, invoiceLineModel!!, position)
        }

        if (mIsReview!!) {
            holder.itemView.mButtonDelete.visibility = View.GONE
            holder.itemView.mButtonMinus.isEnabled = false
            holder.itemView.mButtonPlus.isEnabled = false
            holder.itemView.mTextViewTaxes.isEnabled = false
        } else {
            holder.itemView.mButtonDelete.visibility = View.VISIBLE
            holder.itemView.mButtonMinus.isEnabled = true
            holder.itemView.mButtonPlus.isEnabled = true
            holder.itemView.mTextViewTaxes.isEnabled = true
        }
        /* delete */
        holder.itemView.mButtonDelete.setOnClickListener {
            if (mItemInteractionListener != null) {
                mItemInteractionListener?.onInteraction(holder.itemView.mButtonDelete, invoiceLineModel!!, position)
            }
        }

        /* minus */
        holder.itemView.mButtonMinus.setOnClickListener {
            if (invoiceLineModel?.quantity == 1) return@setOnClickListener
            invoiceLineModel?.quantity = invoiceLineModel?.quantity!! - 1
            holder.itemView.mTextViewOrderedQty.text = invoiceLineModel?.quantity.toString()
            mItemInteractionListener?.onInteraction(holder.itemView.mButtonMinus, invoiceLineModel!!, position)
        }

        /* plus */
        holder.itemView.mButtonPlus.setOnClickListener {
            invoiceLineModel?.quantity = invoiceLineModel?.quantity!! + 1
            holder.itemView.mTextViewOrderedQty.text = invoiceLineModel?.quantity.toString()
            mItemInteractionListener?.onInteraction(holder.itemView.mButtonPlus, invoiceLineModel!!, position)
        }

        /* taxes */
        holder.itemView.mTextViewTaxes.setOnClickListener {
            mItemInteractionListener?.onInteraction(holder.itemView.mTextViewTaxes, invoiceLineModel!!, position)
        }
    }


    class InvoicesViewHolder(view: View) : RecyclerView.ViewHolder(view)

}