package appex.co.eastlog.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable

class StockProductQtyModel :Serializable {
    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("location_id")
    @Expose
    var locationId: List<Any>? = null
    @SerializedName("new_quantity")
    @Expose
    var newQuantity: Float? = null
    @SerializedName("product_tmpl_id")
    @Expose
    var productTmplId: List<Any>? = null
    @SerializedName("lot_id")
    @Expose
    var lotId: Boolean? = null
    @SerializedName("display_name")
    @Expose
    var displayName: String? = null
    @SerializedName("product_variant_count")
    @Expose
    var productVariantCount: Float? = null
    @SerializedName("product_id")
    @Expose
    var productId: List<Any>? = null
}