package appex.co.eastlog.view.dialog

import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.ProductTypeAdapter
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import kotlinx.android.synthetic.main.fragment_taxes_dialog.*

private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [TaxesDialogFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [TaxesDialogFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class ProductTypeDialogFragment : BottomSheetDialogFragment() {

    private var param1: String? = null
    private var param2: String? = null
    private var mListener: OnFragmentInteractionListener? = null

    private var mProductTypeAdapter: ProductTypeAdapter? = null
    private var mListData: ArrayList<String>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_taxes_dialog, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        mTextViewNameBottomSheet.text = "Product Type"

        mListData = ArrayList()
        mProductTypeAdapter = ProductTypeAdapter(activity!!, mListData)
        mProductTypeAdapter?.setItemInteractionListener(object : AbstractAdapter.ListItemInteractionListener {
            override fun onInteraction(view: View, model: Any, position: Int) {
                mListener?.onFragmentInteraction(model.toString())
                dismissAllowingStateLoss()
            }

        })
        //display layout
        val mLayoutManager = LinearLayoutManager(activity!!)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewBottomSheet.layoutManager = mLayoutManager
        mRecyclerViewBottomSheet.setHasFixedSize(true)
        mRecyclerViewBottomSheet.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewBottomSheet.isNestedScrollingEnabled = false
        mRecyclerViewBottomSheet.adapter = mProductTypeAdapter

        fetchData()
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val bottomSheetDialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog
        bottomSheetDialog.setOnShowListener { dia ->
            val dialog = dia as BottomSheetDialog
            val bottomSheet = dialog.findViewById<FrameLayout>(com.google.android.material.R.id.design_bottom_sheet)
//            BottomSheetBehavior.from(bottomSheet!!).state = BottomSheetBehavior.STATE_EXPANDED
            BottomSheetBehavior.from(bottomSheet).skipCollapsed = true
            BottomSheetBehavior.from(bottomSheet).isHideable = true
        }
        return bottomSheetDialog
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
//        if (context is OnFragmentInteractionListener) {
//            listener = context
//        } else {
//            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
//        }
    }

    override fun onDetach() {
        super.onDetach()
        mListener = null
    }

    fun setListener(listener: OnFragmentInteractionListener) {
        mListener = listener
    }

    private fun fetchData() {
        mListData?.add("")
        mListData?.add("Consumable")
        mListData?.add("Service")
        mListData?.add("Stockable Product")
        mProductTypeAdapter?.notifyDataSetChanged()
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     *
     * See the Android Training lesson [Communicating with Other Fragments]
     * (http://developer.android.com/training/basics/fragments/communicating.html)
     * for more information.
     */
    interface OnFragmentInteractionListener {
        fun onFragmentInteraction(type: String?)
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment TaxesDialogFragment.
         */
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                TaxesDialogFragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM1, param1)
                        putString(ARG_PARAM2, param2)
                    }
                }
    }
}
