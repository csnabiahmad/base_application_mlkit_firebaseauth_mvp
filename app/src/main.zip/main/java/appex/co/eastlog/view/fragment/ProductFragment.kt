package appex.co.eastlog.view.fragment

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.util.SparseArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.ProductAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.ProductModel
import appex.co.eastlog.view.activity.ProductDetailActivity
import com.google.android.gms.vision.barcode.Barcode
import com.google.gson.Gson
import com.notbytes.barcode_reader.BarcodeReaderActivity
import com.notbytes.barcode_reader.BarcodeReaderFragment
import kotlinx.android.synthetic.main.fragment_product.*
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.listeners.IOdooResponse


private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Activities that contain this fragment must implement the
 * [ProductFragment.OnFragmentInteractionListener] interface
 * to handle interaction events.
 * Use the [ProductFragment.newInstance] factory method to
 * create an instance of this fragment.
 *
 */
class ProductFragment : Fragment(), AbstractAdapter.ListItemInteractionListener, BarcodeReaderFragment.BarcodeReaderListener {

    private var param1: String? = null
    private var param2: String? = null
    private var listener: OnFragmentInteractionListener? = null

    private var mProgressDlg: ProgressDlg? = null
    private var mProductAdapter: ProductAdapter? = null
    private var mListData: ArrayList<ProductModel>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            param1 = it.getString(ARG_PARAM1)
            param2 = it.getString(ARG_PARAM2)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_product, container, false)
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mListData = ArrayList()
        mProgressDlg = ProgressDlg(activity)

        mProductAdapter = ProductAdapter(activity!!, mListData)
        mProductAdapter!!.setItemInteractionListener(this)

        val mLayoutManager = LinearLayoutManager(activity)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewProduct.layoutManager = mLayoutManager
        mRecyclerViewProduct.setHasFixedSize(true)
        mRecyclerViewProduct.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewProduct.adapter = mProductAdapter
        mRecyclerViewProduct.addOnScrollListener(object : RecyclerView.OnScrollListener(){
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (dy > 0) mFloatingActionButtonAddProduct.hide()
                else mFloatingActionButtonAddProduct.show()
                super.onScrolled(recyclerView, dx, dy)
            }
        })


        //search customer
        mSearchViewProduct.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextChange(newText: String?): Boolean {
                activity!!.runOnUiThread {
                    mProductAdapter?.filter?.filter(newText)
                }
                return false
            }

            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

        })

        mSwipeRefreshLayout.setOnRefreshListener {
            fetchData()
        }

        /* scan barcode */
        mImageViewScanBarcode.setOnClickListener {
            val launchIntent = BarcodeReaderActivity.getLaunchIntent(activity, true, false)
            startActivityForResult(launchIntent, BARCODE_READER_ACTIVITY_REQUEST)
        }

        /* add product */
        mFloatingActionButtonAddProduct.setOnClickListener {
            activity?.runOnUiThread {
                val intent = Intent(activity, ProductDetailActivity::class.java)
                startActivity(intent)
            }
        }

        mProgressDlg?.show()
        fetchData()

        /* show button add product */
        if (MyApplication.getClient()?.user!!.isSuperuser || MyApplication.mOwner?.groupsId!!.contains(14)) {
            mFloatingActionButtonAddProduct.show()
        } else {
            mFloatingActionButtonAddProduct.hide()
        }
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
//        if (context is OnFragmentInteractionListener) {
//            listener = context
//        } else {
//            throw RuntimeException(context.toString() + " must implement OnFragmentInteractionListener")
//        }
    }

    override fun onDetach() {
        super.onDetach()
        listener = null
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode === Activity.RESULT_OK && requestCode === BARCODE_READER_ACTIVITY_REQUEST) {
            val barcode = data?.getParcelableExtra<Barcode>(BarcodeReaderActivity.KEY_CAPTURED_BARCODE)
            Log.e("barcode", Gson().toJson(barcode))
            if (barcode?.rawValue === "False") {
                Toast.makeText(activity, "Please, Check Barcode Product!", Toast.LENGTH_LONG).show()
                return
            }
            val intent = ProductDetailActivity.getStartIntent(activity!!, null, barcode = barcode?.rawValue)
            startActivity(intent)
        }
    }


    override fun onInteraction(view: View, model: Any, position: Int) {
        val productModel = model as ProductModel
        val intent = ProductDetailActivity.getStartIntent(activity!!, Gson().toJson(productModel), barcode = null)
        startActivity(intent)
    }

    override fun onScanned(barcode: Barcode?) {
    }

    override fun onScannedMultiple(barcodes: MutableList<Barcode>?) {
    }

    override fun onBitmapScanned(sparseArray: SparseArray<Barcode>?) {
    }

    override fun onScanError(errorMessage: String?) {
    }

    override fun onCameraPermissionDenied() {
    }

    private fun fetchData() {
        val fields = OdooFields()
        fields.addAll(
                "id", "name", "categ_id", "services", "consumable",
                "filter_to_sell", "filter_to_purchase", "inactive", "attribute_line_ids", "pricelist_id",
                "activities_overdue", "activities_today", "activities_upcoming_all", "list_price",
                "image_medium", "type", "default_code", "standard_price", "qty_available", "virtual_available",
                "barcode", "sale_ok", "purchase_ok"
        )
        val offset = 0
        val limit = 1000
        val sorting = ""
        val domain = ODomain()
        domain.add("type", "!=", "service") //or domain.add("type", "in", listof("product", "consumable"))
        domain.add("sale_ok", "=", "1")
        MyApplication.mClient?.searchRead(
                Constants.MODEL_PRODUCT_TEMPLATE, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        if (mListData!!.size > 0) mListData?.clear()

                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<ProductModel>::class.java
                        )
                        mListData?.addAll(data)

                        activity!!.runOnUiThread {
                            if (mSwipeRefreshLayout.isRefreshing) {
                                mSwipeRefreshLayout.isRefreshing = false
                            }
                            mProductAdapter?.notifyDataSetChanged()
                            mProgressDlg?.hide()
                        }


                    }
                })
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     *
     *
     * See the Android Training lesson [Communicating with Other Fragments]
     * (http://developer.android.com/training/basics/fragments/communicating.html)
     * for more information.
     */
    interface OnFragmentInteractionListener {
        fun onFragmentInteraction(uri: Uri)
    }

    companion object {
        const val BARCODE_READER_ACTIVITY_REQUEST = 1111

        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param param1 Parameter 1.
         * @param param2 Parameter 2.
         * @return A new instance of fragment ProductFragment.
         */
        @JvmStatic
        fun newInstance(param1: String, param2: String) =
                ProductFragment().apply {
                    arguments = Bundle().apply {
                        putString(ARG_PARAM1, param1)
                        putString(ARG_PARAM2, param2)
                    }
                }
    }
}
