package appex.co.eastlog.view.activity

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.InvoicesAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.Customer
import appex.co.eastlog.model.InvoicesModel
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_invoices.*
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.listeners.IOdooResponse


class InvoicesActivity : AppCompatActivity(), AbstractAdapter.ListItemInteractionListener {

    private var mProgressDlg: ProgressDlg? = null
    private var mCustomer: Customer? = null
    private var mInvoicesAdapter: InvoicesAdapter? = null
    private var mListData: ArrayList<InvoicesModel>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invoices)

        setSupportActionBar(mToolbarCommon)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        title = ""

        mListData = ArrayList()
        mInvoicesAdapter = InvoicesAdapter(applicationContext, mListData)
        mInvoicesAdapter?.setItemInteractionListener(this)
        mProgressDlg = ProgressDlg(this)
        mProgressDlg?.show()

        val mLayoutManager = LinearLayoutManager(applicationContext)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewInvoices.layoutManager = mLayoutManager
        mRecyclerViewInvoices.setHasFixedSize(true)
        mRecyclerViewInvoices.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewInvoices.adapter = mInvoicesAdapter

        intent.extras.let {
            val data = it[Constants.EXTRA_CUSTOMER]
            mCustomer = Gson().fromJson(data.toString(), Customer::class.java)
            getData()

        }

        mSwipeRefreshLayout.setOnRefreshListener {
            getData()
        }

        mFloatingActionButtonAddInvoice.setOnClickListener {
            val intent = Intent(applicationContext, CreateInvoiceActivity::class.java)
            startActivity(intent)
        }
    }


    private fun getData() {
        val fields = OdooFields()
        fields.addAll(
                "partner_id", "date_invoice", "number",
                "commercial_partner_id", "reference", "name",
                "journal_id", "company_id", "user_id",
                "date_due", "origin", "amount_total_signed",
                "residual_signed", "currency_id", "company_currency_id",
                "state", "type", "invoice_line_ids", "amount_untaxed", "amount_tax", "amount_total"
        )
        val offset = 0
        val limit = 80
        val sorting = "date_invoice DESC"
        val domain = ODomain()
        domain.add(Constants.PARTNER_ID, "=", mCustomer?.id!!.toInt())
        MyApplication.mClient?.searchRead(Constants.MODEL_ACCOUNT_INVOICE, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        if (mListData!!.size > 0) mListData?.clear()
                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<InvoicesModel>::class.java
                        )
                        mListData?.addAll(data)
                        runOnUiThread {
                            if (mSwipeRefreshLayout.isRefreshing) {
                                mSwipeRefreshLayout.isRefreshing = false
                            }
                            mInvoicesAdapter?.notifyDataSetChanged()
                            mProgressDlg?.hide()
                            if (mListData?.size == 0) {
                                mRecyclerViewInvoices.visibility = View.GONE
                                mTextViewStatus.visibility = View.VISIBLE
                            }
                        }
                    }
                })
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> onBackPressed()
        }
        return super.onOptionsItemSelected(item)

    }

    override fun onInteraction(view: View, model: Any, position: Int) {
        val invoice = model as InvoicesModel

        val intent = Intent(this@InvoicesActivity, InvoicesDetailActivity::class.java)
        intent.putExtra(Constants.EXTRA_INVOICE, Gson().toJson(invoice))
        startActivity(intent)
    }
}
