package appex.co.eastlog.view.custom

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import androidx.viewpager.widget.ViewPager

class LockableViewPager : ViewPager {

    private var mSwipeable: Boolean = false

    constructor(context: Context) : super(context) {}

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        this.mSwipeable = false//default dismiss swipe viewpager
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        return if (this.mSwipeable) {
            super.onTouchEvent(event)
        } else false

    }

    override fun onInterceptTouchEvent(event: MotionEvent): Boolean {
        return if (this.mSwipeable) {
            super.onInterceptTouchEvent(event)
        } else false

    }

    fun setSwipeable(swipeable: Boolean) {
        this.mSwipeable = swipeable
    }
}