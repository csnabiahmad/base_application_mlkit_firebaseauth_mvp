package appex.co.eastlog.view.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.SearchView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.CustomerInvoiceAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.Customer
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_customer.*
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.listeners.IOdooResponse

class CustomerActivity : AppCompatActivity(), AbstractAdapter.ListItemInteractionListener {

    private var mProgressDlg: ProgressDlg? = null
    private var mCustomerAdapter: CustomerInvoiceAdapter? = null
    private var mListData: ArrayList<Customer>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer)

        setSupportActionBar(mToolbarCreateInvoice)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)
        mListData = ArrayList()

        mCustomerAdapter = CustomerInvoiceAdapter(applicationContext, mListData)
        mCustomerAdapter!!.setItemInteractionListener(this)

        val mLayoutManager = LinearLayoutManager(applicationContext)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewCustomerInvoice.layoutManager = mLayoutManager
        mRecyclerViewCustomerInvoice.setHasFixedSize(true)
        mRecyclerViewCustomerInvoice.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewCustomerInvoice.adapter = mCustomerAdapter

        mProgressDlg = ProgressDlg(this@CustomerActivity)

        //search customer
        mSearchViewCustomer.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextChange(newText: String?): Boolean {
                runOnUiThread {
                    mCustomerAdapter?.filter?.filter(newText)
                }
                return false
            }

            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

        })

        mSwipeRefreshLayout.setOnRefreshListener {
            fetchData()
        }
    }

    override fun onResume() {
        super.onResume()
        runOnUiThread {
            mProgressDlg?.show()
            fetchData()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> onBackPressed()
        }
        return super.onOptionsItemSelected(item)

    }


    fun fetchData() {
        val fields = OdooFields()
        fields.addAll(
                "id", "color", "display_name", "title",
                "email", "parent_id", "is_company", "function", "phone",
                "street", "street2", "zip", "city", "country_id", "mobile", "state_id",
                "category_id", "image_small", "type", "website", "fax"
        )
        val offset = 0
        val limit = 80
        val sorting = "name DESC"
        val domain = ODomain()
        domain.add("customer", "=", true)
        MyApplication.mClient?.searchRead(Constants.MODEL_RES_PARTNER, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        if (mListData!!.size > 0) mListData?.clear()

                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<Customer>::class.java
                        )
                        mListData?.addAll(data)

                        runOnUiThread {
                            if (mSwipeRefreshLayout.isRefreshing) {
                                mSwipeRefreshLayout.isRefreshing = false
                            }
                            mCustomerAdapter?.notifyDataSetChanged()
                            mProgressDlg?.hide()
                        }

                    }
                })
    }

    override fun onInteraction(view: View, model: Any, position: Int) {
        val customer = model as Customer
        val intent = Intent()
        intent.putExtra(Constants.EXTRA_CUSTOMER, Gson().toJson(customer))
        setResult(Activity.RESULT_OK, intent)
        finish()
    }
}
