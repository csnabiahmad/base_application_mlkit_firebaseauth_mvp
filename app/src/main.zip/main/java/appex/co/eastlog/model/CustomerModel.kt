package appex.co.eastlog.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable


class CustomerModel : Serializable {
    @SerializedName("length")
    @Expose
    var length: Float? = null
    @SerializedName("records")
    @Expose
    var records: MutableList<Customer>? = null
}

class Customer : Serializable {

    companion object {

        const val NAME = "name"
        const val MOBILE = "mobile"
        const val PHONE = "phone"
        const val EMAIL = "email"
        const val STREET = "street"
        const val STREET2 = "street2"
        const val WEBSITE = "website"
        const val FAX = "fax"
        const val CITY = "city"
        const val ZIP = "zip"
        const val IMAGE_MEDIUM = "image_medium"
        const val IMAGE_SMALL = "image_small"
    }

    @SerializedName("image_small")
    @Expose
    var imageSmall: String? = null
    @SerializedName("country_id")
    @Expose
    var countryId: Any? = null
    @SerializedName("state_id")
    @Expose
    var stateId: Any? = null
    @SerializedName("color")
    @Expose
    var color: Float? = null
    @SerializedName("function")
    @Expose
    var function: String? = null
    @SerializedName("street")
    @Expose
    var street: String? = null
    @SerializedName("category_id")
    @Expose
    var categoryId: MutableList<Any>? = null
    @SerializedName("groups_id")
    @Expose
    var groupsId: List<Int>? = null
    @SerializedName("mobile")
    @Expose
    var mobile: String? = null
    @SerializedName("street2")
    @Expose
    var street2: String? = null
    @SerializedName("id")
    @Expose
    var id: Float? = null
    @SerializedName("display_name")
    @Expose
    var displayName: String? = null
    @SerializedName("parent_id")
    @Expose
    var parentId: Any? = null
    @SerializedName("zip")
    @Expose
    var zip: String? = null
    @SerializedName("city")
    @Expose
    var city: String? = null
    @SerializedName("phone")
    @Expose
    var phone: String? = null
    @SerializedName("title")
    @Expose
    var title: Any? = null
    @SerializedName("email")
    @Expose
    var email: String? = null
    @SerializedName("type")
    @Expose
    var type: String? = null
    @SerializedName("is_company")
    @Expose
    var isCompany: String? = null
    @SerializedName("website")
    @Expose
    var website: String? = null
    @SerializedName("opportunity_count")
    @Expose
    var opportunityCount: Int? = null
    @SerializedName("meeting_count")
    @Expose
    var meetingCount: Int? = null
    @SerializedName("sale_order_count")
    @Expose
    var saleOrderCount: Int? = null
    @SerializedName("total_invoiced")
    @Expose
    var totalInvoiced: Float? = null
    @SerializedName("fax")
    @Expose
    var fax: String? = null
}