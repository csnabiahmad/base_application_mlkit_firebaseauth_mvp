package appex.co.eastlog.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import odoo.client.OdooVersion
import java.io.Serializable


class UserModel : Serializable {
    @SerializedName("companyId")
    @Expose
    var companyId: Int? = null
    @SerializedName("database")
    @Expose
    var database: String? = null
    @SerializedName("host")
    @Expose
    var host: String? = null
    @SerializedName("isSuperuser")
    @Expose
    var isSuperuser: Boolean? = null
    @SerializedName("lang")
    @Expose
    var lang: String? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("odooVersion")
    @Expose
    var odooVersion: OdooVersion? = null
    @SerializedName("partnerId")
    @Expose
    var partnerId: Int? = null
    @SerializedName("sessionId")
    @Expose
    var sessionId: String? = null
    @SerializedName("tz")
    @Expose
    var tz: String? = null
    @SerializedName("uid")
    @Expose
    var uid: Int? = null
    @SerializedName("username")
    @Expose
    var username: String? = null
}