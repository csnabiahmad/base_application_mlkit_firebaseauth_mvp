package appex.co.eastlog.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable


class InvoicesModel : Serializable {

    companion object {
        const val ID = "id"
        const val PARTNER_ID = "partner_id"
        const val PAYMENT_TERM_ID = "payment_term_id"
        const val DATE_INVOICE = "date_invoice"
        const val DATE_DUE = "date_due"
        const val USER_ID = "user_id"
        const val INVOICE_LINE_IDS = "invoice_line_ids"
        const val AMOUNT_UNTAXED = "amount_untaxed"
        const val AMOUNT_TAX = "amount_tax"
        const val AMOUNT_TOTAL = "amount_total"
        const val STATE = "state"

        //refister payment
        const val AMOUNT = "amount"
        const val PAYMENT_DATE = "payment_date"
        const val JOURNAL_ID = "journal_id"
        const val COMMUNICATION = "communication"
        const val PAYMENT_TYPE = "payment_type"
        const val PAYMENT_METHOD_ID = "payment_method_id"
        const val INVOICE_IDS = "invoice_ids"
        const val CURRENCY_ID = "currency_id"
        const val DEFAULT_INVOICE_IDS = "default_invoice_ids"
    }

    @SerializedName("number")
    @Expose
    var number: String? = null
    @SerializedName("journal_id")
    @Expose
    var journalId: List<Any>? = null
    @SerializedName("currency_id")
    @Expose
    var currencyId: List<Any>? = null
    @SerializedName("date_due")
    @Expose
    var dateDue: String? = null
    @SerializedName("company_currency_id")
    @Expose
    var companyCurrencyId: List<Any>? = null
    @SerializedName("date_invoice")
    @Expose
    var dateInvoice: String? = null
    @SerializedName("reference")
    @Expose
    var reference: Boolean? = null
    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("residual_signed")
    @Expose
    var residualSigned: Float? = null
    @SerializedName("partner_id")
    @Expose
    var partnerId: List<Any>? = null
    @SerializedName("company_id")
    @Expose
    var companyId: List<Any>? = null
    @SerializedName("origin")
    @Expose
    var origin: String? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("commercial_partner_id")
    @Expose
    var commercialPartnerId: List<Any>? = null
    @SerializedName("amount_total_signed")
    @Expose
    var amountTotalSigned: Float? = null
    @SerializedName("user_id")
    @Expose
    var userId: List<Any>? = null
    @SerializedName("type")
    @Expose
    var type: String? = null
    @SerializedName("state")
    @Expose
    var state: String? = null
    @SerializedName("amount_untaxed")
    @Expose
    var amountUntaxed: String? = null
    @SerializedName("amount_tax")
    @Expose
    var amountTax: String? = null
    @SerializedName("amount_total")
    @Expose
    var amountTotal: String? = null
    @SerializedName("invoice_line_ids")
    @Expose
    var invoiceLineIds: List<Float>? = null
    @SerializedName("payment_ids")
    @Expose
    var paymentIds: List<Float>? = null
}