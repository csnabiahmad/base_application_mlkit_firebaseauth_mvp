package appex.co.eastlog.view.activity

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import appex.co.eastlog.R
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.utils.SharedPreference
import com.google.gson.Gson
import odoo.OdooClient
import odoo.OdooUser
import odoo.client.AuthError
import odoo.client.OdooVersion
import odoo.client.listeners.AuthenticateListener
import java.util.concurrent.TimeUnit

class SplashActivity : AppCompatActivity() {

    private var mLocalData: SharedPreference? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        mLocalData = SharedPreference.getInstance(applicationContext)
        val dateLogin = mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_TIME)
        runOnUiThread {
            if (dateLogin == null || TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - dateLogin!!.toLong()) > 30) {
                Handler().postDelayed({
                    val intent = Intent(applicationContext, LoginActivity::class.java)
                    startActivity(intent)
                    finishAffinity()
                }, 1000)
            } else {
                MyApplication.mClient = OdooClient.Builder(applicationContext)
                        .setHost(Constants.BASE_URL)
                        .setConnectListener { version: OdooVersion? ->
                            val username = mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_USERNAME)
                            val password = mLocalData?.getData(Constants.SHARED_PREFERENCES_KEY_PASSWORD)
                            MyApplication.mClient?.authenticate(username,
                                    password,
                                    Constants.DATABASE,
                                    object : AuthenticateListener {
                                        override fun onLoginSuccess(user: OdooUser?) {
                                            runOnUiThread {
                                                Log.e("OdooUser", Gson().toJson(user))
                                                val intent = Intent(applicationContext, MainActivity::class.java)
                                                startActivity(intent)
                                                finishAffinity()
                                            }
                                        }

                                        override fun onLoginFail(error: AuthError?) {
                                            runOnUiThread {
                                                val intent = Intent(applicationContext, LoginActivity::class.java)
                                                startActivity(intent)
                                                finishAffinity()
//                                                Toast.makeText(applicationContext, Gson().toJson(error), Toast.LENGTH_LONG).show()
                                            }
                                        }
                                    })
                        }.setErrorListener {
                            val intent = Intent(applicationContext, LoginActivity::class.java)
                            startActivity(intent)
                            finishAffinity()
                        }.build()
            }
        }
    }
}
