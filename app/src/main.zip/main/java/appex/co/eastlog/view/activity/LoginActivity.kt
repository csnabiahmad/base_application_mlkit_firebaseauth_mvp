package appex.co.eastlog.view.activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import appex.co.eastlog.R
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.utils.SharedPreference
import appex.co.eastlog.utils.Utils
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_login.*
import odoo.OdooClient
import odoo.OdooUser
import odoo.client.AuthError
import odoo.client.OdooVersion
import odoo.client.listeners.AuthenticateListener


class LoginActivity : AppCompatActivity() {

    private var mProgressDlg: ProgressDlg? = null
    private var mLocalData: SharedPreference? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        //init data
        mProgressDlg = ProgressDlg(this)
        mLocalData = SharedPreference.getInstance(applicationContext)

        MyApplication.mClient = OdooClient.Builder(applicationContext)
                .setHost(Constants.BASE_URL)
                .setConnectListener { version: OdooVersion? ->
//                    Log.e("OdooUser", Gson().toJson(version))
                }.build()

        mButtonLogin.setOnClickListener {
            val username = mEditTextUsername.text.toString().trim()
            val password = mEditTextPassword.text.toString().trim()
            if (username.isNullOrBlank()) {
                Toast.makeText(applicationContext, getString(R.string.error_provide_username), Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            if (password.isNullOrBlank()) {
                Toast.makeText(applicationContext, getString(R.string.error_provide_password), Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            mProgressDlg?.show()
            MyApplication.mClient?.authenticate(username,
                    password,
                    Constants.DATABASE,
                    object : AuthenticateListener {
                        override fun onLoginSuccess(user: OdooUser?) {
//                            Log.e("OdooUser", user.toString())
                            runOnUiThread {
                                if (mCheckBoxSavePassword.isChecked){
                                    mLocalData!!.saveData(Constants.SHARED_PREFERENCES_KEY_USERNAME, username)
                                    mLocalData!!.saveData(Constants.SHARED_PREFERENCES_KEY_PASSWORD, password)
                                    mLocalData!!.saveData(Constants.SHARED_PREFERENCES_KEY_TIME, System.currentTimeMillis().toString())
                                }
                                mProgressDlg?.hide()
                                Utils.hideSoftKeyboard(this@LoginActivity)
                                val intent = Intent(this@LoginActivity, MainActivity::class.java)
                                startActivity(intent)
                                finishAffinity()
                            }
                        }

                        override fun onLoginFail(error: AuthError?) {
                            runOnUiThread {
                                mProgressDlg?.hide()
                                Toast.makeText(applicationContext, Gson().toJson(error), Toast.LENGTH_LONG).show()
                            }
                        }
                    })
        }
    }
}
