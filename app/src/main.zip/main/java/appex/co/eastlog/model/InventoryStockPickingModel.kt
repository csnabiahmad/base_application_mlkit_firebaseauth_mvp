package appex.co.eastlog.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable

class InventoryStockPickingModel : Serializable {

    @SerializedName("scheduled_date")
    @Expose
    var scheduledDate: String? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("backorder_id")
    @Expose
    var backorderId: Any? = null
    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("location_dest_id")
    @Expose
    var locationDestId: List<Any>? = null
    @SerializedName("date")
    @Expose
    var date: String? = null
    @SerializedName("picking_type_id")
    @Expose
    var pickingTypeId: List<Any>? = null
    @SerializedName("partner_id")
    @Expose
    var partnerId: Any? = null
    @SerializedName("priority")
    @Expose
    var priority: String? = null
    @SerializedName("state")
    @Expose
    var state: String? = null
    @SerializedName("origin")
    @Expose
    var origin: String? = null
//    @SerializedName("group_id")
//    @Expose
//    var groupId: List<Any>? = null

}