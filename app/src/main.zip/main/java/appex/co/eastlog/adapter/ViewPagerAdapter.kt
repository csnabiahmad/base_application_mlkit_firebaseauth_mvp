package appex.co.eastlog.adapter

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter

class ViewPagerAdapter(context: Context, fm: FragmentManager) : FragmentPagerAdapter(fm) {

    private var mFragmentList = ArrayList<Fragment>()
    private var mFragmentTitleList = ArrayList<String>()
    private var mContext = context

    override fun getItem(position: Int): Fragment {
        return mFragmentList[position]
    }

    fun addFragment(frag: Fragment, title: String) {
        mFragmentList.add(frag)
        mFragmentTitleList.add(title)
    }


    override fun getCount(): Int {
        return mFragmentList.size
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return mFragmentTitleList[position]
    }
}