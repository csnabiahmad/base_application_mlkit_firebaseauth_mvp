package appex.co.eastlog.view.fragment

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import androidx.core.app.ActivityOptionsCompat
import androidx.core.view.ViewCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.CustomerAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.Customer
import appex.co.eastlog.utils.Utils
import appex.co.eastlog.view.activity.CustomerDetailActivity
import appex.co.eastlog.view.activity.InvoicesActivity
import com.google.gson.Gson
import kotlinx.android.synthetic.main.fragment_customer.*
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.listeners.IOdooResponse

class CustomerFragment : Fragment(), AbstractAdapter.ListItemInteractionListener {

    private var mProgressDlg: ProgressDlg? = null
    private var mCustomerAdapter: CustomerAdapter? = null
    private var mListData: ArrayList<Customer>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_customer, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mListData = ArrayList()
        mProgressDlg = ProgressDlg(activity)

        mCustomerAdapter = CustomerAdapter(activity!!, mListData)
        mCustomerAdapter!!.setItemInteractionListener(this)

        val mLayoutManager = LinearLayoutManager(activity!!)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewCustomer.layoutManager = mLayoutManager
        mRecyclerViewCustomer.setHasFixedSize(true)
        mRecyclerViewCustomer.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewCustomer.adapter = mCustomerAdapter
        mRecyclerViewCustomer.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (dy > 0) mFloatingActionButtonAddCustomer.hide()
                else mFloatingActionButtonAddCustomer.show()
                super.onScrolled(recyclerView, dx, dy)
            }
        })


        mFloatingActionButtonAddCustomer.setOnClickListener {
            Utils.hideSoftKeyboard(activity!!)
            val intent = Intent(activity, CustomerDetailActivity::class.java)
            intent.putExtra(Constants.EXTRA_IS_EDIT_CUSTOMER, false)
            startActivity(intent)
        }

        //search customer
        mSearchViewCustomer.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextChange(newText: String?): Boolean {
                activity!!.runOnUiThread {
                    mCustomerAdapter?.filter?.filter(newText)
                }
                return false
            }

            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

        })

        mSwipeRefreshLayout.setOnRefreshListener {
            fetchData()
        }

        mProgressDlg?.show()
        Utils.hideSoftKeyboard(activity!!)
        fetchData()

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode === Activity.RESULT_OK && requestCode === CUSTOMER_CODE_UPDATE) {
            mProgressDlg?.show()
            Utils.hideSoftKeyboard(activity!!)
            fetchData()
        }
    }

    fun fetchData() {
        val fields = OdooFields()
        fields.addAll(
                "id", "color", "display_name", "title",
                "email", "parent_id", "is_company", "function", "phone",
                "street", "street2", "zip", "city", "country_id", "mobile", "state_id",
                "category_id", "image_small", "type", "website", "fax", "opportunity_count",
                "meeting_count", "sale_order_count", "total_invoiced"
        )
        val offset = 0
        val limit = 80
        val sorting = "name DESC"
        val domain = ODomain()
        domain.add("customer", "=", true)
        domain.add("parent_id", "=", false)
        MyApplication.mClient?.searchRead(Constants.MODEL_RES_PARTNER, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        if (mListData!!.size > 0) mListData?.clear()

                        val data = Gson().fromJson(
                                Gson().toJson(result!!.records),
                                Array<Customer>::class.java
                        )
                        mListData?.addAll(data)

                        activity!!.runOnUiThread {
                            if (mSwipeRefreshLayout.isRefreshing) {
                                mSwipeRefreshLayout.isRefreshing = false
                            }
                            mCustomerAdapter?.notifyDataSetChanged()
                            mProgressDlg?.hide()
                        }

                    }
                })
    }

    override fun onInteraction(view: View, model: Any, position: Int) {
        val customer = model as Customer
        when (view.id) {
            R.id.mButtonInvoices -> {
                mProgressDlg?.show()
                activity!!.runOnUiThread {
                    val intent = Intent(activity, InvoicesActivity::class.java)
                    intent.putExtra(Constants.EXTRA_CUSTOMER, Gson().toJson(customer))
                    intent.putExtra(Constants.EXTRA_IS_EDIT_CUSTOMER, true)
                    activity!!.startActivity(intent)
                    mProgressDlg?.hide()
                }
            }
            else -> {
                val intent = Intent(activity, CustomerDetailActivity::class.java)
                intent.putExtra(Constants.EXTRA_CUSTOMER, Gson().toJson(customer))
                intent.putExtra(Constants.EXTRA_IS_EDIT_CUSTOMER, true)
                intent.putExtra(EXTRA_ANIMAL_IMAGE_TRANSITION_NAME, ViewCompat.getTransitionName(view)!!)

                val options = ActivityOptionsCompat.makeSceneTransitionAnimation(activity!!, view, ViewCompat.getTransitionName(view)!!)
                activity!!.startActivityForResult(intent, CUSTOMER_CODE_UPDATE, options.toBundle())
            }
        }
    }

    companion object {
        const val CUSTOMER_CODE_UPDATE = 1112
        val EXTRA_ANIMAL_IMAGE_TRANSITION_NAME = "animal_image_transition_name"
    }
}
