package appex.co.eastlog.view.activity

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.adapter.AbstractAdapter
import appex.co.eastlog.adapter.InvoiceLineAdapter
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.model.Customer
import appex.co.eastlog.model.InvoiceLineModel
import appex.co.eastlog.model.InvoicesModel
import appex.co.eastlog.utils.Utils
import com.google.gson.Gson
import kotlinx.android.synthetic.main.activity_invoices_detail.*
import kotlinx.android.synthetic.main.layout_toolbar.*
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.ODomain
import odoo.client.helper.utils.OdooFields
import odoo.client.listeners.IOdooResponse

class InvoicesDetailActivity : AppCompatActivity(), AbstractAdapter.ListItemInteractionListener {


    private var mInvoicesModel: InvoicesModel? = null
    private var mProductAdapter: InvoiceLineAdapter? = null
    private var mListDataProduct: ArrayList<InvoiceLineModel>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_invoices_detail)

        setSupportActionBar(mToolbarCommon)
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setDisplayShowHomeEnabled(true)

        mListDataProduct = ArrayList()
        mProductAdapter = InvoiceLineAdapter(applicationContext, mListDataProduct)
        mProductAdapter?.setItemInteractionListener(this)

        val mLayoutManager = LinearLayoutManager(applicationContext)
        mLayoutManager.orientation = RecyclerView.VERTICAL
        mRecyclerViewProduct.layoutManager = mLayoutManager
        mRecyclerViewProduct.isNestedScrollingEnabled = false
        mRecyclerViewProduct.setHasFixedSize(true)
        mRecyclerViewProduct.itemAnimator = DefaultItemAnimator() as RecyclerView.ItemAnimator?
        mRecyclerViewProduct.adapter = mProductAdapter

        intent.extras.let {
            val data = it[Constants.EXTRA_INVOICE] ?: return
            mInvoicesModel = Gson().fromJson(data.toString(), InvoicesModel::class.java)

            val fields = OdooFields()
            fields.addAll(
                    "sequence", "product_id", "origin",
                    "is_rounding_line", "name", "company_id",
                    "account_id", "account_analytic_id", "analytic_tag_ids",
                    "quantity", "uom_id", "price_unit",
                    "discount", "invoice_line_tax_ids", "price_subtotal", "currency_id"
            )
            val offset = 0
            val limit = 80
            val sorting = "name DESC"
            val domain = ODomain()
//            mInvoicesModel?.invoiceLineIds?.forEachIndexed { index, fl ->
//                domain.add(Constants.ID, "=", fl)
//            }
            domain.add(Constants.ID, "in", mInvoicesModel?.invoiceLineIds)

            MyApplication.mClient?.searchRead(Constants.MODEL_ACCOUNT_INVOICE_LINE,
                    domain,
                    fields,
                    offset,
                    limit,
                    sorting,
                    object : IOdooResponse() {
                        override fun onResult(result: OdooResult?) {
                            val data = Gson().fromJson(
                                    Gson().toJson(result!!.records),
                                    Array<InvoiceLineModel>::class.java
                            )
                            mListDataProduct?.addAll(data)
                            runOnUiThread {
                                mProductAdapter?.notifyDataSetChanged()
                                if (mListDataProduct?.size == 0) {
                                    mRecyclerViewProduct.visibility = View.GONE
                                } else {
                                    mRecyclerViewProduct.visibility = View.VISIBLE
                                }
                            }
                        }
                    })

            mTextViewNumber.text = Utils.getString(mInvoicesModel?.number)
            mTextViewCustomer.text = mInvoicesModel?.partnerId!![1].toString()
            mTextViewInvoiceDate.text = Utils.getString(mInvoicesModel?.dateInvoice)
            mTextViewDueDate.text = Utils.getString(mInvoicesModel?.dateDue)
            mTextViewSale.text = mInvoicesModel?.userId!![1].toString()
            mTextViewAmount.text = mInvoicesModel?.amountUntaxed + " $"
            mTextViewTax.text = mInvoicesModel?.amountTax + " $"
            mTextViewTotal.text = mInvoicesModel?.amountTotal + " $"

        }

        mLinearLayoutCustomer.setOnClickListener {
            Utils.hideSoftKeyboard(this@InvoicesDetailActivity)
            val fields = OdooFields()
            fields.addAll(
                    "id", "color", "display_name", "title",
                    "email", "parent_id", "is_company", "function", "phone",
                    "street", "street2", "zip", "city", "country_id", "mobile", "state_id",
                    "category_id", "image_small", "type", "website", "fax"
            )
            val offset = 0
            val limit = 80
            val sorting = "name DESC"
            val domain = ODomain()
            domain.add("customer", "=", true)
            domain.add("id", "=", mInvoicesModel?.partnerId!![0].toString().toFloat())
            MyApplication.mClient?.searchRead(Constants.MODEL_RES_PARTNER, domain, fields, offset, limit, sorting,
                    object : IOdooResponse() {
                        override fun onResult(result: OdooResult?) {
                            val data = Gson().fromJson(
                                    Gson().toJson(result!!.records),
                                    Array<Customer>::class.java
                            )
                            val customer = Gson().toJson(data[0])
                            val intent = Intent(this@InvoicesDetailActivity, CustomerDetailActivity::class.java)
                            intent.putExtra(Constants.EXTRA_CUSTOMER, customer)
                            intent.putExtra(Constants.EXTRA_IS_EDIT_CUSTOMER, true)
                            startActivity(intent)
                        }
                    })

        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            android.R.id.home -> onBackPressed()
        }
        return super.onOptionsItemSelected(item)

    }

    override fun onInteraction(view: View, model: Any, position: Int) {

    }
}
