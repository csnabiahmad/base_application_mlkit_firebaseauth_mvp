package appex.co.eastlog.view.activity

import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Base64
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import appex.co.eastlog.R
import appex.co.eastlog.common.Constants
import appex.co.eastlog.common.MyApplication
import appex.co.eastlog.common.PopUpDlg
import appex.co.eastlog.common.ProgressDlg
import appex.co.eastlog.model.ProductCategoryModel
import appex.co.eastlog.model.ProductModel
import appex.co.eastlog.utils.Utils
import appex.co.eastlog.view.dialog.ProductCategoryDialogFragment
import appex.co.eastlog.view.dialog.ProductTypeDialogFragment
import appex.co.eastlog.view.fragment.ProductFragment
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.google.android.gms.vision.barcode.Barcode
import com.google.gson.Gson
import com.notbytes.barcode_reader.BarcodeReaderActivity
import com.yanzhenjie.album.Album
import kotlinx.android.synthetic.main.activity_product_detail.*
import odoo.client.helper.OdooErrorException
import odoo.client.helper.data.OdooResult
import odoo.client.helper.utils.*
import odoo.client.listeners.IOdooResponse
import java.io.ByteArrayOutputStream

class ProductDetailActivity : AppCompatActivity() {

    private var mProductModel: ProductModel? = null
    private var mProgressDlg: ProgressDlg? = null
    private var isCreate: Boolean? = false
    private var mProductCategory: ProductCategoryModel? = null
    private var mBitmapBackground: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        mScrollView.visibility = View.GONE

        setSupportActionBar(mToolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        title = ""
        mProgressDlg = ProgressDlg(this@ProductDetailActivity)

        /* handler bundle activity */
        intent.let {
            val dataSub = intent.getStringExtra(EXTRAS_PRODUCT)
            val dataSubBarcode = intent.getStringExtra(EXTRAS_PRODUCT_BARCODE)
            when {
                dataSub != null -> {
                    isCreate = false
                    mProductModel = Gson().fromJson(dataSub, ProductModel::class.java)
                    initData()
                }
                dataSubBarcode != null -> {
                    isCreate = false
                    fetchDataFromBarcode(dataSubBarcode)
                }
                else -> {
                    isCreate = true
                    mTextViewNumber.text = "Create Product"
                    mTextViewSave.visibility = View.VISIBLE
                    mScrollView.visibility = View.VISIBLE
                    mCheckBoxSale.isChecked = true
                    mCheckBoxPurchased.isChecked = true

                    Glide.with(applicationContext)
                            .load(R.drawable.icon_placeholder)
                            .placeholder(R.drawable.icon_placeholder)
                            .into(mImageViewAvatar)
                }
            }
        }

        mImageViewAvatar.setOnClickListener {
            if (!isCreate!!) return@setOnClickListener
            Album.album(this)
                    .singleChoice()
                    .columnCount(2)
                    .camera(true)
                    .cameraVideoQuality(0)
                    .cameraVideoLimitDuration(Integer.MAX_VALUE.toLong())
                    .cameraVideoLimitBytes(Integer.MAX_VALUE.toLong())
                    .onResult { result ->
                        Glide.with(applicationContext)
                                .asBitmap()
                                .load(result!![0].path)
                                .into(object : SimpleTarget<Bitmap>(128, 128) {
                                    override fun onResourceReady(resource: Bitmap, transition: Transition<in Bitmap>?) {
                                        mBitmapBackground = resource
                                        mImageViewAvatar.setImageBitmap(resource)
                                    }
                                })
                    }.onCancel {
                        Toast.makeText(applicationContext, R.string.canceled, Toast.LENGTH_LONG).show()
                    }
                    .start()
        }

        /* product type */
        mLinearLayoutProductType.setOnClickListener {
            val productType = ProductTypeDialogFragment()
            productType.setListener(object : ProductTypeDialogFragment.OnFragmentInteractionListener {
                override fun onFragmentInteraction(type: String?) {
                    mTextViewProductType.text = type.toString()
                    when (type) {
                        "Stockable Product" -> {
                            mLinearLayoutOnHand.visibility = View.VISIBLE
                        }
                        else -> {
                            mLinearLayoutOnHand.visibility = View.GONE
                        }
                    }
                }
            })
            productType.show(supportFragmentManager.beginTransaction(), "")
        }

        /* category */
        mLinearLayoutCategory.setOnClickListener {
            val productCategory = ProductCategoryDialogFragment()
            productCategory.setListener(object : ProductCategoryDialogFragment.OnFragmentInteractionListener {
                override fun onFragmentInteraction(productCategory: String?) {
                    mProductCategory = Gson().fromJson(productCategory, ProductCategoryModel::class.java)
                    mTextViewCategory.text = mProductCategory?.displayName
                }
            })
            productCategory.show(supportFragmentManager.beginTransaction(), "")
        }

        /* save product */
        mTextViewSave.setOnClickListener {
            if (mTextViewSave.text == getString(R.string.save)) {
                saveProduct()
//                mTextViewSave.text = getString(R.string.edit)
                return@setOnClickListener
            }
            mTextViewSave.text = getString(R.string.save)
            updateStateView(true)
        }

        /* scan barcode */
        mImageViewScanBarcode.setOnClickListener {
            Utils.hideSoftKeyboard(this@ProductDetailActivity)
            val launchIntent = BarcodeReaderActivity.getLaunchIntent(applicationContext, true, false)
            startActivityForResult(launchIntent, BARCODE_READER_ACTIVITY_REQUEST)
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode === Activity.RESULT_OK && requestCode === ProductFragment.BARCODE_READER_ACTIVITY_REQUEST) {
            val barcode = data?.getParcelableExtra<Barcode>(BarcodeReaderActivity.KEY_CAPTURED_BARCODE)
            if (barcode?.rawValue === "False") {
                Toast.makeText(applicationContext, "Please, Check Barcode Product!", Toast.LENGTH_LONG).show()
                return
            }
            mEditTextBarcode.setText(barcode?.rawValue)
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            android.R.id.home -> onBackPressed()
        }
        return super.onOptionsItemSelected(item)
    }

    private fun initData() {
        updateStateView(isCreate)
        mScrollView.visibility = View.VISIBLE
        mTextViewSave.visibility = View.VISIBLE

        mTextViewSave.text = getString(R.string.edit)
        /* name */
        mTextViewNumber.text = mProductModel?.name

        mEditTextName.setText(mProductModel?.name)
        /* image */
        if (mProductModel?.imageMedium != "false") {
            val imageByteArray = Base64.decode(mProductModel?.imageMedium, 0)
            val options = BitmapFactory.Options()
            options.inMutable = true
            mBitmapBackground = BitmapFactory.decodeByteArray(imageByteArray, 0, imageByteArray?.size!!, options)
            mImageViewAvatar.setImageBitmap(mBitmapBackground)
        }

        /* product type */
        mTextViewProductType.text = when (mProductModel?.type) {
            "consu" -> "Consumable"
            "service" -> "Service"
            "product" -> "Stockable Product"
            else -> ""
        }

        /* category */
        mProductCategory = ProductCategoryModel()
        mProductCategory?.id = mProductModel?.categId!![0].toString().toFloat().toInt()
        mProductCategory?.displayName = mProductModel?.categId!![1].toString()
        mProductCategory?.name = mProductModel?.categId!![1].toString()

        mTextViewCategory.text = mProductModel?.categId!![1].toString()

        /* code */
        mEditTextInternalReference.setText(mProductModel?.defaultCode)

        /* price */
        mEditTextSalesPrice.setText("$ " + mProductModel?.listPrice.toString())

        /* cost */
        mEditTextCost.setText("$ " + mProductModel?.standard_price.toString())

        when (mProductModel?.type) {
            "product" -> {
                mLinearLayoutOnHand.visibility = View.VISIBLE
                mLinearLayoutForecasted.visibility = View.VISIBLE
            }
            else -> {
                mLinearLayoutOnHand.visibility = View.GONE
                mLinearLayoutForecasted.visibility = View.GONE
            }
        }
        /* on hand */
        mEditTextOnHand.setText(mProductModel?.qtyAvailable.toString())

        /* forecasted */
        mEditTextForecasted.setText(mProductModel?.virtualAvailable.toString())

        /* barcode */
        mEditTextBarcode.setText(mProductModel?.barcode)

        /* can be sold */
        mCheckBoxSale.isChecked = mProductModel?.saleOk!!

        mCheckBoxPurchased.isChecked = mProductModel?.purchaseOk!!

    }

    private fun fetchDataFromBarcode(barcode: String?) {
        mProgressDlg?.show()
        val fields = OdooFields()
        fields.addAll(
                "id", "name", "categ_id", "services", "consumable",
                "filter_to_sell", "filter_to_purchase", "inactive", "attribute_line_ids", "pricelist_id",
                "activities_overdue", "activities_today", "activities_upcoming_all", "list_price",
                "image_medium", "type", "default_code", "standard_price", "qty_available", "virtual_available",
                "barcode", "sale_ok", "purchase_ok"
        )
        val offset = 0
        val limit = 1
        val sorting = "name ASC"
        val domain = ODomain()
        domain.add("type", "!=", "service") //or domain.add("type", "in", listof("product", "consumable"))
        domain.add("barcode", "=", barcode)
        MyApplication.mClient?.searchRead(
                Constants.MODEL_PRODUCT_TEMPLATE, domain, fields, offset, limit, sorting,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult?) {
                        mProgressDlg?.hide()
//                        Log.e("barcode OdooResult", Gson().toJson(result))
                        if (result!!.records.isNotEmpty()) {
                            val data = Gson().fromJson(Gson().toJson(result!!.records), Array<ProductModel>::class.java)
                            mProductModel = data[0]
                            initData()
                        } else {
                            mScrollView.visibility = View.GONE
                            val popUpDlg = PopUpDlg(this@ProductDetailActivity, false)
                            popUpDlg.show("", "Please, Check Barcode Product!", getString(R.string.common_ok), "",
                                    DialogInterface.OnClickListener { dialog, whichButton ->
                                        dialog.dismiss()
                                        finish()
                                    }, null)
                        }
                    }
                })
    }

    private fun saveProduct() {
        mProgressDlg?.show()
        Utils.hideSoftKeyboard(this@ProductDetailActivity)
        val name = mEditTextName.text.toString()
        val sale = mCheckBoxSale.isChecked
        val purchased = mCheckBoxPurchased.isChecked
        val productType = when (mTextViewProductType.text.toString()) {
            "Consumable" -> "consu"
            "Service" -> "service"
            "Stockable Product" -> "product"
            else -> ""
        }
        val category = mProductCategory?.id
        val internalReference = mEditTextInternalReference.text.toString()
        val salePrice = mEditTextSalesPrice.text.toString().replace("$ ", "")
        val cost = mEditTextCost.text.toString().replace("$ ", "")
        val qtyOnHand = mEditTextOnHand.text.toString().replace("$ ", "")
        val barcode = mEditTextBarcode.text.toString()

        if (name.isNullOrEmpty()) {
            Toast.makeText(applicationContext, getString(R.string.error_provide_name), Toast.LENGTH_LONG).show()
            return
        }
        val values = OdooValues()
        values.put("name", name)
        values.put("sale_ok", sale)
        values.put("purchase_ok", purchased)
        values.put("type", productType)
        values.put("categ_id", category)
        values.put("default_code", internalReference)
        values.put("list_price", salePrice)
        values.put("standard_price", cost)
        values.put("barcode", barcode)
        if (mBitmapBackground != null) {
            val stream = ByteArrayOutputStream()
            mBitmapBackground?.compress(Bitmap.CompressFormat.PNG, 100, stream)
            val byteArray = stream.toByteArray()
            val imageBase64 = Base64.encodeToString(byteArray, Base64.DEFAULT)
            values.put("image_medium", imageBase64)
        }

        if (isCreate!!) {
            MyApplication.mClient?.create(Constants.MODEL_PRODUCT_TEMPLATE, values, object : IOdooResponse() {
                override fun onResult(result: OdooResult?) {
                    runOnUiThread {
                        if (productType == "product") {
                            updateQtyOnHand(qtyOnHand = qtyOnHand.toInt(), productId = result!!.getFloat("result").toInt())
                        } else {
                            mProgressDlg?.hide()
                            val popUpDlg = PopUpDlg(this@ProductDetailActivity, false)
                            popUpDlg.show("", getString(R.string.create_product), getString(R.string.common_ok), "",
                                    DialogInterface.OnClickListener { dialog, whichButton ->
                                        dialog.dismiss()
                                        setResult(Activity.RESULT_OK, Intent())
                                        finish()
                                    }, null)
                        }

                    }
                }

                override fun onError(error: OdooErrorException?): Boolean {
                    Log.e("MODEL_PRODUCT_TEMPLATE", error?.message)
                    mProgressDlg?.hide()
                    val popUpDlg = PopUpDlg(this@ProductDetailActivity, false)
                    popUpDlg.show("", error?.message!!, getString(R.string.common_ok), "",
                            DialogInterface.OnClickListener { dialog, whichButton ->
                                dialog.dismiss()
                            }, null)
                    return true
                }
            })
        } else {
            MyApplication.mClient?.write(Constants.MODEL_PRODUCT_TEMPLATE,
                    arrayOf(mProductModel?.id!!.toInt()),
                    values,
                    object : IOdooResponse() {
                        override fun onResult(result: OdooResult?) {
                            updateStateView(false)
                            if (productType == "product") {
                                updateQtyOnHand(qtyOnHand = qtyOnHand.toInt(), productId = mProductModel?.id!!)
                            }
                            title = mEditTextName.text.toString()
                            Toast.makeText(applicationContext, getString(R.string.update_customer), Toast.LENGTH_LONG).show()
                        }

                        override fun onError(error: OdooErrorException?): Boolean {
                            mProgressDlg?.hide()
                            val popUpDlg = PopUpDlg(this@ProductDetailActivity, false)
                            popUpDlg.show("", error?.message!!, getString(R.string.common_ok), "",
                                    DialogInterface.OnClickListener { dialog, whichButton ->
                                        dialog.dismiss()
                                    }, null)
                            return true
                        }
                    })
        }
    }

    private fun updateStateView(edit: Boolean?) {
        when (edit) {
            true -> {
                mEditTextName.isEnabled = true
                mCheckBoxSale.isEnabled = true
                mCheckBoxPurchased.isEnabled = true
                mLinearLayoutProductType.isEnabled = true
                mLinearLayoutCategory.isEnabled = true
                mEditTextBarcode.isEnabled = true
                mImageViewScanBarcode.isEnabled = true
                mEditTextInternalReference.isEnabled = true
                mEditTextSalesPrice.isEnabled = true
                mEditTextCost.isEnabled = true
                mEditTextOnHand.isEnabled = true
                mEditTextForecasted.isEnabled = true

            }
            else -> {
                mEditTextName.isEnabled = false
                mCheckBoxSale.isEnabled = false
                mCheckBoxPurchased.isEnabled = false
                mLinearLayoutProductType.isEnabled = false
                mLinearLayoutCategory.isEnabled = false
                mEditTextBarcode.isEnabled = false
                mImageViewScanBarcode.isEnabled = false
                mEditTextInternalReference.isEnabled = false
                mEditTextSalesPrice.isEnabled = false
                mEditTextCost.isEnabled = false
                mEditTextOnHand.isEnabled = false
                mEditTextForecasted.isEnabled = false
            }
        }
    }

    private fun updateQtyOnHand(qtyOnHand: Int, productId: Int) {
        if (mProductModel != null) {
            if (mProductModel?.qtyAvailable?.toInt() == qtyOnHand) {
                return
            }
        }

        val params = OdooParams()
        params.add("model", "stock.change.product.qty")
        params.add("method", "create")

        /* add args*/
        val paramQuantityStockProduct = OdooParams()
        paramQuantityStockProduct.add("new_quantity", qtyOnHand)
        paramQuantityStockProduct.add("product_tmpl_id", productId)
        paramQuantityStockProduct.add("location_id", 14)
        paramQuantityStockProduct.add("lot_id", false)
        val arguments = OArguments()
        arguments.add(paramQuantityStockProduct)
        params.add("args", arguments.get())

        /* context */
        val paramKwargs = OdooParams()
        paramKwargs.put("action", 175)

        val contextKwargs = OdooParams()
        contextKwargs.put("uid", MyApplication.getClient()!!.user.uid)
        contextKwargs.put("active_model", "product.template")
        contextKwargs.put("active_id", productId)
        contextKwargs.put("active_ids", OArguments().add(productId).array)
        contextKwargs.put("product_id", productId)
        contextKwargs.put("search_disable_custom_filters", true)
        contextKwargs.put("params", paramKwargs)

        val valueKwargs = OdooParams()
        valueKwargs.put("context", contextKwargs)

        params.add("kwargs", valueKwargs)
        MyApplication.mClient?.callController(Constants.BASE_URL + Constants.MODEL_STOCK_CHANGE_PRODUCT_QTY_CREATE,
                params,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult) {
                        callCreateQtyOnhand(result.getFloat("result").toInt(), productId)
                    }

                    override fun onError(error: OdooErrorException?): Boolean {
                        Log.e("OdooErrorException", error?.message)
                        Toast.makeText(applicationContext!!, error?.message?.trim(), Toast.LENGTH_LONG).show()
                        return true
                    }
                })
    }

    private fun callCreateQtyOnhand(id: Int, productId: Int) {
        val params = OdooParams()
        params.add("model", "stock.change.product.qty")
        params.add("method", "change_product_qty")
        params.add("context_id", MyApplication.getClient()?.user?.uid!!.toInt())

        /* add args*/
        val arguments = OArguments()
        arguments.add(id)
        val paramsOrder = OdooParams()
        paramsOrder.add("uid", MyApplication.getClient()?.user?.uid)
        paramsOrder.add("active_id", productId)
        paramsOrder.add("active_ids", productId)
        paramsOrder.add("active_model", "product.template")
        paramsOrder.add("params", OdooParams().add("action", 175))
        paramsOrder.add("search_disable_custom_filters", true)
        arguments.add(paramsOrder)
        params.add("args", arguments.get())

        MyApplication.mClient?.callController(Constants.BASE_URL + Constants.CONTROLLER_CALL_BUTTON,
                params,
                object : IOdooResponse() {
                    override fun onResult(result: OdooResult) {
                        mProgressDlg?.hide()
                        Log.e("change_product_qty", result.toString())
                        val popUpDlg = PopUpDlg(this@ProductDetailActivity, false)
                        popUpDlg.show("", getString(R.string.create_product), getString(R.string.common_ok), "",
                                DialogInterface.OnClickListener { dialog, whichButton ->
                                    dialog.dismiss()
                                    setResult(Activity.RESULT_OK, Intent())
                                    finish()
                                }, null)
                    }

                    override fun onError(error: OdooErrorException?): Boolean {
                        Log.e("OdooErrorException", error?.message)
                        Toast.makeText(applicationContext!!, error?.message?.trim(), Toast.LENGTH_LONG).show()
                        return true
                    }
                })
    }

    companion object {
        //constants
        private const val EXTRAS_PRODUCT = "extras_product"
        private const val EXTRAS_PRODUCT_BARCODE = "extras_product_barcode"
        private const val BARCODE_READER_ACTIVITY_REQUEST = 1111

        fun getStartIntent(context: Context, product: String?, barcode: String?): Intent {
            val intent = Intent(context, ProductDetailActivity::class.java)
            intent.putExtra(EXTRAS_PRODUCT, product)
            intent.putExtra(EXTRAS_PRODUCT_BARCODE, barcode)
            return intent
        }
    }
}
