package appex.co.eastlog.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable

class ProductModel : Serializable {
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("list_price")
    @Expose
    var listPrice: Float? = null
    @SerializedName("categ_id")
    @Expose
    var categId: List<Any>? = null
    @SerializedName("id")
    @Expose
    var id: Int? = null
    @SerializedName("pricelist_id")
    @Expose
    var pricelistId: Any? = null
    @SerializedName("attribute_line_ids")
    @Expose
    var attributeLineIds: List<Any>? = null
    @SerializedName("default_code")
    @Expose
    var defaultCode: String? = null
    @SerializedName("type")
    @Expose
    var type: String? = null
    @SerializedName("standard_price")
    @Expose
    var standard_price: Float? = null
    @SerializedName("image_medium")
    @Expose
    var imageMedium: String? = null
    @SerializedName("qty_available")
    @Expose
    var qtyAvailable: Float? = null
    @SerializedName("virtual_available")
    @Expose
    var virtualAvailable: Float? = 1f
    @SerializedName("barcode")
    @Expose
    var barcode: String? = null

    @SerializedName("sale_ok")
    @Expose
    var saleOk: Boolean? = null
    @SerializedName("purchase_ok")
    @Expose
    var purchaseOk: Boolean? = null

    var productUomQty: Int? = 1

    var taxes: TaxesModel? = null


    companion object {
        const val ID = "id"
        const val PARTNER_ID = "partner_id"
        const val VALIDITY_DATE = "validity_date"
        const val STATE = "state"

        const val ACCOUNT_ID = "account_id"
        const val PRODUCT_ID = "product_id"
        const val DESCRIPTION = "name"
        const val PRICE_UNIT = "price_unit"
        const val QUANTITY = "product_uom_qty"
        const val PRICE_SUBTOTAL = "price_subtotal"
        const val ORDER_ID = "order_id"
        /* taxes */
        const val TAX_ID = "tax_id"
        const val INVOICE_ID = "invoice_id"
        const val AMOUNT_TOTAL = "amount_total"
        const val AMOUNT = "amount"
        const val AMOUNT_ROUNDING = "amount_rounding"
        const val DISPLAY_NAME = "display_name"
        const val NAME = "name"


    }
}