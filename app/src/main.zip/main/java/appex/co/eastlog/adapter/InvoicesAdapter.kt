package appex.co.eastlog.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.model.InvoicesModel
import appex.co.eastlog.utils.Utils
import kotlinx.android.synthetic.main.layout_item_invoices.view.*


class InvoicesAdapter(private val mContext: Context, private var mListData: ArrayList<InvoicesModel>?) :
    AbstractAdapter(), Filterable {

    private var mListDataFull: ArrayList<InvoicesModel>? = null

    init {
        mListDataFull = ArrayList()
        mListDataFull?.addAll(mListData!!.clone() as Collection<InvoicesModel>)
    }

    private var mItemInteractionListener: AbstractAdapter.ListItemInteractionListener? = null
    /**
     * @param listener
     */
    fun setItemInteractionListener(listener: AbstractAdapter.ListItemInteractionListener) {
        this.mItemInteractionListener = listener
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return InvoicesViewHolder(
            LayoutInflater.from(mContext).inflate(R.layout.layout_item_invoices, parent, false)
        )
    }

    override fun getItemCount(): Int {
        return mListData!!.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val invoices = mListData?.get(position)

        /**
         * display name
         */
        holder.itemView.mTextViewName.text = invoices?.partnerId!![1].toString()

        /**
         *  total
         */
        holder.itemView.mTextViewTotal.text = invoices?.amountTotalSigned.toString() + " $"

        /**
         *  number
         */
        holder.itemView.mTextViewNumber.text = Utils.getString(invoices?.number)

        /**
         *  date invoice
         */
        holder.itemView.mTextViewInvoiceDate.text = Utils.getString(invoices?.dateInvoice)

        /**
         *  status
         */
        holder.itemView.mTextViewStatus.text = invoices.state
        when (invoices.state) {
            "open" -> holder.itemView.mTextViewStatus.setBackgroundResource(R.drawable.orange_border)
            "paid" -> holder.itemView.mTextViewStatus.setBackgroundResource(R.drawable.green_border)
            else -> holder.itemView.mTextViewStatus.setBackgroundResource(R.drawable.gray_border)
        }

        holder.itemView.mLinearLayout.setOnClickListener {
            if (mItemInteractionListener != null) {
                mItemInteractionListener?.onInteraction(holder.itemView, invoices!!, position)
            }
        }
    }

    override fun getFilter(): Filter {
        return customerFilter
    }

    class InvoicesViewHolder(view: View) : RecyclerView.ViewHolder(view)

    private val customerFilter = object : Filter() {

        override fun performFiltering(constraint: CharSequence?): FilterResults {
            val filteredList = ArrayList<InvoicesModel>()

            if (constraint == null || constraint.isEmpty()) {
                filteredList.addAll(mListDataFull!!)
            } else {
                val filterPattern = constraint.toString().toLowerCase().trim()

                for (item in mListDataFull!!) {
                    if (item?.partnerId!![1].toString()!!.toLowerCase().contains(filterPattern)) {
                        filteredList.add(item)
                    }
                }
            }
            val results = FilterResults()
            results.values = filteredList

            return results
        }

        override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
            if (results!!.values == null) return
            mListData?.clear()
            mListData?.addAll(results!!.values as ArrayList<InvoicesModel>)
            notifyDataSetChanged()
        }
    }
}