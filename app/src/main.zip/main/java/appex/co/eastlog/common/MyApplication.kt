package appex.co.eastlog.common

import android.app.Application
import appex.co.eastlog.model.Customer
import appex.co.eastlog.utils.MediaLoader
import com.yanzhenjie.album.Album
import com.yanzhenjie.album.AlbumConfig
import odoo.OdooClient
import java.util.*

class MyApplication : Application() {

    companion object {
        var mOwner: Customer? = null
        var mClient: OdooClient? = null
        var mApplication: MyApplication? = null
        fun getInstance(): MyApplication? {
            return mApplication
        }

        fun getClient(): OdooClient? {
//            if (mClient == null) {
//                mClient = OdooClient.Builder(mApplication)
//                    .setHost(Constants.BASE_URL)
//                    .setConnectListener { version: OdooVersion? ->
//                    }.build()
//            }
            return mClient
        }
    }


    override fun onCreate() {
        super.onCreate()
        mApplication = this

        Album.initialize(
                AlbumConfig.newBuilder(this)
                        .setAlbumLoader(MediaLoader())
                        .setLocale(Locale.getDefault())
                        .build()
        )
    }
}