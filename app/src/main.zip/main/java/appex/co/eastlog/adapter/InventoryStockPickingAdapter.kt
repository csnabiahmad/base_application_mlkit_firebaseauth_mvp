package appex.co.eastlog.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import appex.co.eastlog.model.InventoryStockPickingModel
import appex.co.eastlog.utils.Utils
import kotlinx.android.synthetic.main.layout_item_inventory_stock_picking.view.*

class InventoryStockPickingAdapter(private val mContext: Context, private var mListData: ArrayList<InventoryStockPickingModel>?) : AbstractAdapter() {

    private var mItemInteractionListener: AbstractAdapter.ListItemInteractionListener? = null

    fun setItemInteractionListener(listener: AbstractAdapter.ListItemInteractionListener) {
        this.mItemInteractionListener = listener
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return InventoryStockPickingViewHolder(LayoutInflater.from(mContext).inflate(R.layout.layout_item_inventory_stock_picking, parent, false))
    }

    override fun getItemCount(): Int {
        return mListData!!.size
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val inventoryStockPicking = mListData?.get(position)

        /* name */
        holder.itemView.mTextViewName.text = Utils.getString(inventoryStockPicking?.name)

        /* state */
        when (inventoryStockPicking?.state) {
            "draft" -> {
                holder.itemView.mTextViewStatus.text = "Draft"
                holder.itemView.mTextViewStatus.background = ContextCompat.getDrawable(mContext, R.drawable.gray_border)
            }
            "waiting" -> {
                holder.itemView.mTextViewStatus.text = "Waiting Another Operation"
                holder.itemView.mTextViewStatus.background = ContextCompat.getDrawable(mContext, R.drawable.orange_border)
            }
            "confirmed" -> {
                holder.itemView.mTextViewStatus.text = "Waiting"
                holder.itemView.mTextViewStatus.background = ContextCompat.getDrawable(mContext, R.drawable.orange_border)
            }
            "assigned" -> {
                holder.itemView.mTextViewStatus.text = "Ready"
                holder.itemView.mTextViewStatus.background = ContextCompat.getDrawable(mContext, R.drawable.purple_border)
            }
            "done" -> {
                holder.itemView.mTextViewStatus.text = "Done"
                holder.itemView.mTextViewStatus.background = ContextCompat.getDrawable(mContext, R.drawable.blue_border)
            }
            else -> {
                holder.itemView.mTextViewStatus.text = "Cancelled"
                holder.itemView.mTextViewStatus.background = ContextCompat.getDrawable(mContext, R.drawable.gray_border)
            }
        }

        /* partner */
        if (inventoryStockPicking!!.partnerId is List<*>) {
            holder.itemView.mTextViewPartner.text = (inventoryStockPicking!!.partnerId as List<*>)[1].toString()
        }

        /* scheduled date */
        holder.itemView.mTextViewScheduledDate.text = Utils.getString(inventoryStockPicking?.scheduledDate.toString().split(" ")[0])

        /* click item */
        holder.itemView.mLinearLayout.setOnClickListener {
            mItemInteractionListener?.onInteraction(holder.itemView, inventoryStockPicking, position)
        }

    }


    class InventoryStockPickingViewHolder(view: View) : RecyclerView.ViewHolder(view)

}