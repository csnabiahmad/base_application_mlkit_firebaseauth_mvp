package appex.co.eastlog.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable


class InventoryDashboardModel : Serializable {

    @SerializedName("count_picking_waiting")
    @Expose
    var countPickingWaiting: Int? = null
    @SerializedName("name")
    @Expose
    var name: String? = null
    @SerializedName("code")
    @Expose
    var code: String? = null
    @SerializedName("count_picking_late")
    @Expose
    var countPickingLate: Int? = null
    @SerializedName("color")
    @Expose
    var color: Float? = null
    @SerializedName("count_picking_backorders")
    @Expose
    var countPickingBackorders: Int? = null
    @SerializedName("count_picking_ready")
    @Expose
    var countPickingReady: Int? = null
    @SerializedName("id")
    @Expose
    var id: Float? = null
    @SerializedName("warehouse_id")
    @Expose
    var warehouseId: List<Any>? = null
    @SerializedName("count_picking_draft")
    @Expose
    var countPickingDraft: Int? = null


}