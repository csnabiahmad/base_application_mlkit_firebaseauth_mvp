package appex.co.eastlog.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import appex.co.eastlog.R
import kotlinx.android.synthetic.main.layout_item_taxes.view.*

class ProductTypeAdapter(private val mContext: Context, private var mListData: MutableList<String>?) : AbstractAdapter() {

    private var mItemInteractionListener: AbstractAdapter.ListItemInteractionListener? = null

    /**
     * @param listener
     */
    fun setItemInteractionListener(listener: AbstractAdapter.ListItemInteractionListener) {
        this.mItemInteractionListener = listener
    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return ProductTypeViewHolder(
                LayoutInflater.from(mContext).inflate(R.layout.layout_item_taxes, viewGroup, false)
        )
    }

    override fun getItemCount(): Int {
        return when (mListData!!.isEmpty()) {
            true -> 0
            false -> mListData!!.size
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val type = mListData!![position]
        //name
        holder.itemView.mTextViewName.text = type

        //handler click
        holder.itemView.setOnClickListener {
            if (mItemInteractionListener != null) {
                mItemInteractionListener!!.onInteraction(holder.itemView, type, position)
            }
        }
    }

    class ProductTypeViewHolder(view: View) : RecyclerView.ViewHolder(view)
}