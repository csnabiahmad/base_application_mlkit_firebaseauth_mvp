package appex.co.eastlog.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import appex.co.eastlog.model.Customer


class CustomerViewModel : ViewModel() {

    var mCustomer = MutableLiveData<Customer>()

    fun getCustomer(): MutableLiveData<Customer> {
        return mCustomer
    }

    fun setCustomer(customer: Customer) {
        mCustomer.value = customer
    }

}